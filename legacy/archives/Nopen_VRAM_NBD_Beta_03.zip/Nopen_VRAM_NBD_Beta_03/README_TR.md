# Nopen VRAM-NBD Beta 0.3 – RX 9060 XT 8 GiB blok aygıtı deneyi

**Önemli: Bu sürüm SWAP için değildir. mkswap, swapon, mkfs ve mount komutlarını uygulamayın.** Burada amaç 8 GiB GPU belleğini Linux'a geçici, ham NBD aygıtı olarak sunmak; baştan, 256 MiB sınırında, 4 GiB sınırında ve sondan doğrudan veri yazıp geri okuyabilmektir.

## Önceki sürümden farkı

Beta 0.2 tek bir 128 MiB OpenCL tamponuyla başarılı çalıştı. Beta 0.3 GPU VRAM'ini **256 MiB'lık bağımsız tamponlara** böler; 8 GiB için 32 tampon ayırır. Bunun amacı OpenCL'nin tek tampon boyutu kısıtından kaçmaktır. NBD istekleri tampon sınırlarını aştığında da bölünerek işlenir. 16 MiB NBD I/O sınırı korunur. Ekran kartı belleğine doğrudan tahsis yapan sürücü çağrıları artacağından **masaüstü çökmesi / GPU sıfırlanması / kaydedilmemiş veri kaybı riski vardır**. Donanımsal zarar beklenmez ama garanti edilemez.

## Derle

```bash
cd ~/nopen-vram-experiment/nbd-beta-03/Nopen_VRAM_NBD_Beta_03
make clean && make
```

## Başlamadan önce

Önemli çalışmalarınızı kaydedin ve GPU tüketen programları kapatın. Önceki Beta 0.2 uygulamasını kapatın (SWAP kullanılmıyorken CTRL+C). Ayrı terminalde:

```bash
sudo modprobe nbd nbds_max=16 max_part=0
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
cat /sys/block/nbd15/pid 2>/dev/null || echo 'nbd15 aktif değil'
```

**Devam etmek için `/dev/nbd15` aygıtı boş olmalı (0B, swap yok, mount yok, PID yok).** Eski sunucu çalışıyor veya aygıt bağlıysa yeni uygulamayı başlatmayın. Modül komutu aygıtı değiştirmez.

## Birinci terminalde 8 GiB VRAM alanı ayır

```bash
cd ~/nopen-vram-experiment/nbd-beta-03/Nopen_VRAM_NBD_Beta_03
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 8192
```

`READY ... 8192 MiB` mesajını bekle. Hata olursa çıktıyı not et; zorlayıp sürdürme. `READY` görünmesi tek başına veri doğrulaması değildir. **Bu terminal açık kalacak.**

## İkinci terminalde 8 GiB adresleme testini çalıştır

```bash
cd ~/nopen-vram-experiment/nbd-beta-03/Nopen_VRAM_NBD_Beta_03
./test-nbd-8g.sh
```

Betik aygıt boyutunu, PID bağlantısını, swap/mount olmadığını kontrol eder. Dört kritik konumda 2 MiB rastgele veri yazar, doğrudan geri okuyup birebir karşılaştırır. SSD üzerinde 8 GiB dosya oluşturmaz; sadece `/tmp` içinde geçici 2 MiB test verisi kullanır.

İkinci terminalde çıktı başarıyla bitince birinci terminalde CTRL+C. Kontrol:

```bash
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS | grep -E '(NAME|nbd15|zram0)'
grep -H . /sys/class/drm/card1/device/mem_info_vram_used
```

## Neden henüz SWAP değil?

NBD veri aktaran daemon'un GPU sürücüsünü çağırması gerekiyor. Gerçek düşük bellek şartlarında köprü veya AMD sürücüsü yeni host RAM sayfaları isterken bellek geri kazanma döngüsüne girilebilir. Bu sürümde sürecin bütün sayfalarını belleğe sabitleme, bellek baskısı testleri, hata kurtarma ve GPU reseti sonrası güvenli kapanış yoktur. GPU reseti olursa takas sayfaları kaybolabilir. Kısa ham blok testini geçmek bu engelleri çözmez.

Şu anda etkin tek SWAP 7.3 GiB /dev/zram0 (öncelik 100). Mevcut SSD üzerinde SWAP yok. İleride hedeflenen sıralama ZRAM(100) > VRAM(50) > NVMe SWAP(10) şeklindedir; şu anda bu sıra etkin değildir.
