# Nopen VRAM-NBD v0.9.2 — Gerçek SWAP-IN sınaması (deneysel)

**UYARI: v0.5 ve v0.9 bütün sistemi kilitlemiştir. Bu sürümün güvenli olduğu kanıtlanmamıştır.**

## Gerçekte değişenler
- GPU/NBD C sunucusu v0.9.1a temelinden gelir. Var olan erken `mlockall(MCL_CURRENT)` düzeni korunmuştur; GPU ayrıldıktan sonra tekrar global `mlockall()` yapılmaz.
- Bağımsız watchdog, yalnız GPU aktarımlarını değil NBD soketindeki bekleyen isteği de kaydeder; **kurtarma veya otomatik yeniden başlatma yapmaz.**
- 1536 MiB **gerçek anonim sayfa SWAP-IN** testi bir **ayrı systemd kullanıcı cgroup** içinde çalışır (RAM limiti 768 MiB, swap limiti 1800 MiB). Test sürecinin RAM sınırı fiziksel RAM'i global olarak doldurmadan swap cache'i geri kazanmaya zorlamayı amaçlar.
- `--require-isolated-memory` kendi cgroup sınırlarını doğrular; cgroup kurulamadıysa veya sınırlar geçersizse test başlamaz.
- `/dev/nbd15` öncelik 200, `/dev/zram0` öncelik 100; NVMe swap yok.

## Sıralama
1. Eski SWAP'i **önce `swapoff`**, ardından eski Nopen servisini kapat. `/dev/nbd15` 0B ve /proc/swaps'te yok olmalı. Cihaz aktif takassa NBD bağlantısını kapatma.
2. `make clean && make && make test`
3. `sudo modprobe nbd nbds_max=16 max_part=0`
4. `./start-v092.sh` (servis + GPU ayırma)
5. Önce önemli dosyaları kaydet. Bilgisayar donabilir. Kabul ediyorsan `./enable-v092.sh`.
6. `swapon --show` ile VRAM 200, ZRAM 100 doğrula.
7. `./run-isolated-cycle.sh` (iki defa 1536 MiB sayfa çıkarma/geri çağırma). Cgroup sınırları ayrı yalnızca test prosesine uygulanır; ana sistem bütününü güvenli yapmaz.
8. Test sonrası `./disable-v092.sh` kullan; **önce oyun/test süreçlerini kapat**, swapoff doğrulanmadan backend'i kapatma.

## Test sonuçları
- `PASS`: disk/NBD okuma artışı + pswpin ve byte doğrulaması gerektirir.
- `INCONCLUSIVE_SWAPIN`: swapcache veya yetersiz gerçek okuma; tamamlandı sanma.
- `FAIL` / kilitlenme: rapor `./collect-after-reboot.sh` ile toplanır.

Bu program CUDA veya ekran kartı BIOS değişikliği gerektirmez. VRAM, CPU RAM'i değildir.

## Önemli teknik sınır
Linux NBD kullanıcı alanı + OpenCL sürücü kombinasyonu ağır bellek baskısında döngüsel bağımlılık yaratabilir. Cgroup baskısını izole etmek, bu tehlikeyi ortadan kaldırmaz. Birkaç başarılı tur, Bannerlord kararlılığını kanıtlamaz.
