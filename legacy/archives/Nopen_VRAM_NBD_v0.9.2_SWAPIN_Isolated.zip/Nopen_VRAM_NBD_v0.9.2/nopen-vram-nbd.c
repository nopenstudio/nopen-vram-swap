#define _GNU_SOURCE
#define CL_TARGET_OPENCL_VERSION 120
#include <CL/cl.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/nbd.h>
#include <sys/sysmacros.h>
#include <sys/resource.h>
#include <sys/prctl.h>
#include "nbd_validate.h"
#include <pthread.h>
#include <poll.h>
#include <signal.h>
#include <time.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <ucontext.h>
#include <sys/syscall.h>

/* Nopen VRAM-NBD v0.9.2 EXPERIMENTAL 2 GiB swap canary.
 * DATA LOSS AND SYSTEM CRASH POSSIBLE. Use ONLY on a verified empty /dev/nbd15.
 * Read /proc/swaps before disconnect, preserve existing ZRAM.
 */
#define BLKSIZE 4096u
/* Kernel can merge multiple 1 MiB dd writes into a single 4 MiB NBD request. */
#define MAX_IO (16u*1024u*1024u)
#define SEGMENT_SIZE (256u*1024u*1024u)
#define CHUNK_IO (1024u*1024u)
#define MAGIC_REQ 0x25609513u
#define MAGIC_REP 0x67446698u

struct io_stats {
    uint64_t reads, writes, flushes, read_bytes, write_bytes, errors;
};
/* Signal diagnostics: async-signal-safe write() only.  The phase describes
 * the last operation on the NBD service thread, not a definitive fault site.
 * OpenCL may have its own worker threads. */
static volatile sig_atomic_t last_phase = 0;
static volatile sig_atomic_t last_opcode = -1;
static int crash_log_fd = -1;
static uint8_t *alt_stack_memory = NULL;
static uint64_t pre_gpu_vram_free = 0;
static volatile sig_atomic_t last_segment = -1;
static volatile sig_atomic_t last_block = -1;
static uint64_t max_gpu_io_us = 0;
static uint64_t slow_gpu_io_count = 0;
/* Independent, locked-stack watchdog: does NOT detach NBD or touch swap.
 * It only records a GPU request taking abnormally long. */
static void log_event(const char *stage, uint64_t value);
static _Atomic uint64_t gpu_io_begin_ns = 0;
static _Atomic uint64_t gpu_io_sequence = 0;
static _Atomic int gpu_io_stage = 0;
static _Atomic bool watchdog_shutdown = false;
/* Request watchdog includes NBD socket read/write stalls, not just OpenCL.
 * A stall is only reported; we NEVER kill/restart NBD while swap is active. */
static _Atomic uint64_t nbd_request_start_ns = 0;
static _Atomic uint64_t nbd_request_sequence = 0;
static _Atomic int nbd_request_phase = 0;

static uint64_t monotonic_ns(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t) != 0) return 0;
    return (uint64_t)t.tv_sec * 1000000000ull + (uint64_t)t.tv_nsec;
}
static void *gpu_watchdog(void *unused) {
    (void)unused;
    uint64_t last_report_seq = UINT64_MAX;
    uint64_t next_warn_ns = 0;
    uint64_t last_nbd_seq = UINT64_MAX;
    uint64_t next_nbd_warn_ns = 0;
    while (!atomic_load_explicit(&watchdog_shutdown, memory_order_relaxed)) {
        struct timespec delay = {.tv_sec=1, .tv_nsec=0};
        nanosleep(&delay, NULL);
        uint64_t since = atomic_load_explicit(&gpu_io_begin_ns, memory_order_acquire);
        uint64_t now = monotonic_ns();
        uint64_t nbd_since = atomic_load_explicit(&nbd_request_start_ns, memory_order_acquire);
        if (nbd_since && now && now >= nbd_since && now - nbd_since >= 3000000000ull) {
            uint64_t nseq = atomic_load_explicit(&nbd_request_sequence, memory_order_relaxed);
            if (nseq != last_nbd_seq || now >= next_nbd_warn_ns) {
                last_nbd_seq = nseq;
                next_nbd_warn_ns = now + 5000000000ull;
                log_event("nbd_request_stall_ms", (now - nbd_since)/1000000ull);
                log_event("nbd_request_stall_phase", (unsigned)atomic_load(&nbd_request_phase));
                fprintf(stderr, "NOPEN092 WATCHDOG: NBD request stalled for %" PRIu64 " ms (phase=%d)\n",
                        (uint64_t)((now - nbd_since)/1000000ull), atomic_load(&nbd_request_phase));
            }
        }
        if (!since || !now || now < since || now - since < 2000000000ull) continue;
        uint64_t seq = atomic_load_explicit(&gpu_io_sequence, memory_order_relaxed);
        if (seq != last_report_seq || now >= next_warn_ns) {
            last_report_seq = seq;
            next_warn_ns = now + 5000000000ull;
            log_event("gpu_stall_ms", (now - since) / 1000000ull);
            log_event("gpu_stall_stage", (uint64_t)(unsigned)atomic_load(&gpu_io_stage));
            fprintf(stderr,"NOPEN092 WATCHDOG: GPU operation stalled for %" PRIu64 " ms (stage=%d)\n",
                    (uint64_t)((now - since) / 1000000ull), atomic_load(&gpu_io_stage));
        }
    }
    return NULL;
}



static size_t append_decimal(char *s, size_t at, unsigned int v) {
    char digits[20]; size_t n=0;
    do { digits[n++] = (char)('0' + v % 10); v /= 10; } while (v && n < sizeof digits);
    while (n) s[at++] = digits[--n];
    return at;
}
static size_t append_hex_addr(char *s, size_t at, uintptr_t v) {
    static const char h[]="0123456789abcdef";
    s[at++]='0'; s[at++]='x';
    for (int shift=(int)(sizeof(uintptr_t)*8)-4; shift>=0; shift-=4)
        s[at++]=h[(v >> shift)&15];
    return at;
}
static void fatal_fault(int sig, siginfo_t *info, void *unused) {
    char msg[256]; size_t n=0;
    const char prefix[]="NOPEN092 FATAL signal=";
    for(size_t i=0;i<sizeof prefix-1;i++) msg[n++]=prefix[i];
    n=append_decimal(msg,n,(unsigned)sig);
    const char stage[]=" phase=";
    for(size_t i=0;i<sizeof stage-1;i++) msg[n++]=stage[i];
    n=append_decimal(msg,n,(unsigned)last_phase);
    const char op[]=" opcode=";
    for(size_t i=0;i<sizeof op-1;i++) msg[n++]=op[i];
    n=append_decimal(msg,n,(unsigned)last_opcode);
    const char code[]=" code=";
    for(size_t i=0;i<sizeof code-1;i++) msg[n++]=code[i];
    n=append_decimal(msg,n,(unsigned)(info ? info->si_code : 0));
    const char addr[]=" fault_address=";
    for(size_t i=0;i<sizeof addr-1;i++) msg[n++]=addr[i];
    n=append_hex_addr(msg,n,(uintptr_t)(info ? info->si_addr : NULL));
    const char seg[]=" segment=";
    for(size_t i=0;i<sizeof seg-1;i++) msg[n++]=seg[i];
    n=append_decimal(msg,n,(unsigned)last_segment);
    const char blk[]=" block4k=";
    for(size_t i=0;i<sizeof blk-1;i++) msg[n++]=blk[i];
    n=append_decimal(msg,n,(unsigned)last_block);
#if defined(__x86_64__) && defined(REG_RIP) && defined(REG_RSP)
    if (unused) {
        const ucontext_t *uc = (const ucontext_t *)unused;
        const char ip[]=" ip=";
        for(size_t i=0;i<sizeof ip-1;i++) msg[n++]=ip[i];
        n=append_hex_addr(msg,n,(uintptr_t)uc->uc_mcontext.gregs[REG_RIP]);
        const char sp[]=" sp=";
        for(size_t i=0;i<sizeof sp-1;i++) msg[n++]=sp[i];
        n=append_hex_addr(msg,n,(uintptr_t)uc->uc_mcontext.gregs[REG_RSP]);
    }
#endif
    msg[n++]='\n';
    (void)write(STDERR_FILENO,msg,n);
    if(crash_log_fd>=0) (void)write(crash_log_fd,msg,n);
    /* SA_RESETHAND restores default disposition before entry. Re-raise on
     * the SAME thread to preserve the original fatal signal for coredumpctl.
     * No OpenCL cleanup / NBD disconnect in a signal handler. */
    sigset_t unblock;
    sigemptyset(&unblock);
    sigaddset(&unblock, sig);
    (void)sigprocmask(SIG_UNBLOCK, &unblock, NULL);
    (void)syscall(SYS_tgkill, getpid(), (pid_t)syscall(SYS_gettid), sig);
    _exit(128+sig);
}
static void install_fault_logging(void) {
    crash_log_fd=open("/var/log/nopen-vram-nbd-v092.log",O_CREAT|O_WRONLY|O_APPEND|O_CLOEXEC|O_NOFOLLOW|O_DSYNC,0600);
    /* Main thread signal handling also works if its regular stack is damaged.
     * OpenCL worker threads have their own alternate-stack requirements. */
    alt_stack_memory = mmap(NULL, 64u*1024u, PROT_READ|PROT_WRITE,
                            MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    if (alt_stack_memory != MAP_FAILED) {
        if (mlock(alt_stack_memory, 64u*1024u) < 0)
            perror("WARNING: cannot lock alternate signal stack");
        stack_t st={.ss_sp=alt_stack_memory, .ss_size=64u*1024u};
        if (sigaltstack(&st,NULL) < 0) perror("sigaltstack");
    } else { alt_stack_memory=NULL; perror("mmap alt signal stack"); }

    if(crash_log_fd<0) perror("diagnostic log (stderr still enabled)");
    struct sigaction sa={0};
    sa.sa_sigaction=fatal_fault;
    sa.sa_flags=SA_SIGINFO | SA_RESETHAND | (alt_stack_memory ? SA_ONSTACK : 0);
    sigemptyset(&sa.sa_mask);
    if(sigaction(SIGBUS,&sa,NULL)<0 || sigaction(SIGSEGV,&sa,NULL)<0)
        perror("sigaction fault handler");
}
static void log_event(const char *stage, uint64_t value) {
    char msg[200];
    int n = snprintf(msg, sizeof msg, "NOPEN092 EVENT stage=%s value=%" PRIu64 "\n", stage, value);
    if (n > 0 && (size_t)n < sizeof msg) {
        if (crash_log_fd >= 0) (void)write(crash_log_fd, msg, (size_t)n);
    }
}
static bool read_u64_sysfs(const char *path, uint64_t *val) {
    FILE *f=fopen(path,"r");
    if (!f) return false;
    unsigned long long v=0;
    int ok=fscanf(f,"%llu",&v);
    fclose(f);
    if (ok != 1) return false;
    *val=(uint64_t)v;
    return true;
}
static void print_gpu_memory(const char *stage) {
    for (int i=0;i<16;i++) {
        char totalpath[160], usedpath[160];
        snprintf(totalpath,sizeof totalpath,"/sys/class/drm/card%d/device/mem_info_vram_total",i);
        snprintf(usedpath,sizeof usedpath,"/sys/class/drm/card%d/device/mem_info_vram_used",i);
        uint64_t total=0,used=0;
        if (read_u64_sysfs(totalpath,&total) && read_u64_sysfs(usedpath,&used) && total>=used) {
            fprintf(stderr,"GPU VRAM %s card%d total=%" PRIu64 " MiB used=%" PRIu64 " MiB free=%" PRIu64 " MiB\n",
                    stage,i,total/1048576,used/1048576,(total-used)/1048576);
            if (!strcmp(stage,"before")) pre_gpu_vram_free=total-used;
            return;
        }
    }
    fprintf(stderr,"GPU VRAM telemetry unavailable (%s).\n",stage);
}
/* Snapshot instruction mappings before any failure; do not read proc files
 * in the fatal signal handler. Logs may contain process address information. */
static void snapshot_maps(void) {
    int in=open("/proc/self/maps", O_RDONLY | O_CLOEXEC);
    if (in < 0) return;
    int out=open("/var/log/nopen-vram-nbd-v092.maps", O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (out >= 0) {
        char b[4096]; ssize_t n;
        while ((n=read(in,b,sizeof b)) > 0) {
            ssize_t at=0;
            while (at < n) {
                ssize_t w=write(out,b+at,(size_t)(n-at));
                if (w <= 0) break;
                at += w;
            }
            if (at != n) break;
        }
        close(out);
    }
    close(in);
}

static volatile sig_atomic_t stop_requested = 0;
static bool swap_experiment = false;
static void stop_signal(int signal_number) { (void)signal_number; stop_requested = 1; }

/* /proc/swaps is read outside signal handlers only. */
static bool swap_is_active(const char *dev) {
    FILE *f = fopen("/proc/swaps", "r");
    if (!f) {
        /* Fail closed if we cannot establish that swap is inactive. */
        return true;
    }
    char line[512], path[256];
    bool active = false;
    while (fgets(line, sizeof line, f)) {
        if (sscanf(line, "%255s", path) == 1 && strcmp(path, dev) == 0) {
            active = true;
            break;
        }
    }
    fclose(f);
    return active;
}

static uint64_t be64(uint64_t value) {
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return ((uint64_t)htonl((uint32_t)(value & 0xffffffff)) << 32) |
           (uint64_t)htonl((uint32_t)(value >> 32));
#else
    return value;
#endif
}

static int recv_all(int fd, void *buf, size_t n) {
    uint8_t *p = (uint8_t *)buf;
    while (n) {
        ssize_t k = recv(fd, p, n, 0);
        if (k == 0) return -1;
        if (k < 0) { if (errno == EINTR) continue; return -1; }
        p += (size_t)k; n -= (size_t)k;
    }
    return 0;
}
static int send_all(int fd, const void *buf, size_t n) {
    const uint8_t *p = (const uint8_t *)buf;
    while (n) {
        ssize_t k = send(fd, p, n, MSG_NOSIGNAL);
        if (k <= 0) { if (k < 0 && errno == EINTR) continue; return -1; }
        p += (size_t)k; n -= (size_t)k;
    }
    return 0;
}

/* NBD WRITE carries request data BEFORE the reply. On rejection we must
 * consume it to keep the socket framing aligned for later requests. */
static int drain_write_payload(int fd, void *scratch, uint32_t length) {
    while (length) {
        size_t n = length < CHUNK_IO ? (size_t)length : CHUNK_IO;
        if (recv_all(fd, scratch, n)) return -1;
        length -= (uint32_t)n;
    }
    return 0;
}

struct gpu {
    cl_context context;
    cl_command_queue queue;
    cl_mem *buffers;
    size_t count;
    uint64_t bytes;
};

static void gpu_destroy(struct gpu *g) {
    if (g->queue) clFinish(g->queue);
    if (g->buffers) {
        for (size_t i = 0; i < g->count; i++)
            if (g->buffers[i]) clReleaseMemObject(g->buffers[i]);
        free(g->buffers);
    }
    if (g->queue) clReleaseCommandQueue(g->queue);
    if (g->context) clReleaseContext(g->context);
    memset(g, 0, sizeof *g);
}

/* All IO is split into bounded chunks, even when an operation crosses a
 * 256 MiB GPU-buffer boundary. This avoids single-allocation OpenCL limits. */
static int gpu_transfer(struct gpu *g, bool is_write, uint64_t offset, uint32_t length, uint8_t *host) {
    while (length != 0) {
        size_t idx = (size_t)(offset / SEGMENT_SIZE);
        size_t within = (size_t)(offset % SEGMENT_SIZE);
        last_segment = (sig_atomic_t)idx;
        last_block = (sig_atomic_t)(offset / BLKSIZE);
        uint64_t left_segment = SEGMENT_SIZE - within;
        size_t amount = length < left_segment ? length : (size_t)left_segment;
        if (amount > CHUNK_IO) amount = CHUNK_IO;
        last_phase = is_write ? 131 : 141;
        struct timespec io_t0 = {0}, io_t1 = {0};
        (void)clock_gettime(CLOCK_MONOTONIC, &io_t0);
        atomic_fetch_add_explicit(&gpu_io_sequence, 1, memory_order_relaxed);
        atomic_store(&gpu_io_stage, is_write ? 131 : 141);
        atomic_store_explicit(&gpu_io_begin_ns, monotonic_ns(), memory_order_release);
        cl_int e = is_write
            ? clEnqueueWriteBuffer(g->queue, g->buffers[idx], CL_TRUE,
                                   within, amount, host, 0, NULL, NULL)
            : clEnqueueReadBuffer(g->queue, g->buffers[idx], CL_TRUE,
                                  within, amount, host, 0, NULL, NULL);
        atomic_store_explicit(&gpu_io_begin_ns, 0, memory_order_release);
        (void)clock_gettime(CLOCK_MONOTONIC, &io_t1);
        uint64_t us = 0;
        if (io_t1.tv_sec >= io_t0.tv_sec) {
            int64_t nsec = (int64_t)io_t1.tv_nsec - (int64_t)io_t0.tv_nsec;
            int64_t sec = (int64_t)io_t1.tv_sec - (int64_t)io_t0.tv_sec;
            int64_t elapsed = sec * 1000000 + nsec / 1000;
            if (elapsed > 0) us = (uint64_t)elapsed;
        }
        if (us > max_gpu_io_us) max_gpu_io_us = us;
        if (us >= 250000) {
            slow_gpu_io_count++;
            if (slow_gpu_io_count <= 20) log_event("slow_gpu_chunk_ms", us / 1000);
        }
        if (e != CL_SUCCESS) {
            log_event(is_write ? "gpu_write_error" : "gpu_read_error",(uint64_t)(uint32_t)e);
            fprintf(stderr, "OpenCL %s error %d at offset %" PRIu64 "\n",
                    is_write ? "write" : "read", e, offset);
            return -1;
        }
        offset += amount;
        host += amount;
        length -= (uint32_t)amount;
    }
    return 0;
}

static int gpu_init(struct gpu *g, uint64_t size) {
    last_phase = 1;
    cl_uint np = 0;
    cl_int e = clGetPlatformIDs(0, NULL, &np);
    if (e != CL_SUCCESS || np == 0) { fprintf(stderr, "OpenCL platform unavailable: %d\n", e); return -1; }
    cl_platform_id *platforms = calloc(np, sizeof *platforms);
    if (!platforms) return -1;
    e = clGetPlatformIDs(np, platforms, NULL);
    cl_device_id device = NULL;
    for (cl_uint i = 0; e == CL_SUCCESS && i < np; ++i) {
        char vendor[256] = {0};
        clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof vendor, vendor, NULL);
        if (!strstr(vendor, "AMD") && !strstr(vendor, "Advanced Micro Devices")) continue;
        if (clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_GPU, 1, &device, NULL) == CL_SUCCESS) break;
        device = NULL;
    }
    free(platforms);
    if (!device) { fprintf(stderr, "No AMD OpenCL GPU found.\n"); return -1; }
    char name[256] = {0};
    clGetDeviceInfo(device, CL_DEVICE_NAME, sizeof name, name, NULL);
    cl_ulong allocmax = 0;
    cl_ulong globalmem = 0;
    clGetDeviceInfo(device, CL_DEVICE_MAX_MEM_ALLOC_SIZE, sizeof allocmax, &allocmax, NULL);
    clGetDeviceInfo(device, CL_DEVICE_GLOBAL_MEM_SIZE, sizeof globalmem, &globalmem, NULL);
    if (SEGMENT_SIZE > allocmax) {
        fprintf(stderr, "GPU single-allocation maximum is smaller than 256 MiB.\n");
        return -1;
    }
    if (size > globalmem * 3 / 4) {
        fprintf(stderr, "Refusing to reserve more than 75%% of GPU global memory.\n");
        return -1;
    }
    g->context = clCreateContext(NULL, 1, &device, NULL, NULL, &e);
    if (!g->context || e != CL_SUCCESS) { fprintf(stderr, "clCreateContext: %d\n", e); goto fail; }
    g->queue = clCreateCommandQueue(g->context, device, 0, &e);
    if (!g->queue || e != CL_SUCCESS) { fprintf(stderr, "clCreateCommandQueue: %d\n", e); goto fail; }
    g->count = (size_t)((size + SEGMENT_SIZE - 1) / SEGMENT_SIZE);
    g->buffers = calloc(g->count, sizeof *g->buffers);
    if (!g->buffers) goto fail;
    uint32_t zero = 0;
    for (size_t i = 0; i < g->count; i++) {
        last_phase = 2;
        if ((i % 4) == 0) log_event("gpu_segment",i);
        uint64_t remain = size - (uint64_t)i * SEGMENT_SIZE;
        size_t len = remain < SEGMENT_SIZE ? (size_t)remain : SEGMENT_SIZE;
        g->buffers[i] = clCreateBuffer(g->context, CL_MEM_READ_WRITE, len, NULL, &e);
        if (!g->buffers[i] || e != CL_SUCCESS) {
            fprintf(stderr, "clCreateBuffer segment %zu/%zu: %d\n", i+1, g->count, e);
            goto fail;
        }
        e = clEnqueueFillBuffer(g->queue, g->buffers[i], &zero, sizeof zero, 0, len, 0, NULL, NULL);
        if (e != CL_SUCCESS) { fprintf(stderr, "clEnqueueFillBuffer: %d\n", e); goto fail; }
    }
    last_phase = 3;
    e = clFinish(g->queue);
    if (e != CL_SUCCESS) { fprintf(stderr, "GPU memory initialization failed: %d\n", e); goto fail; }
    g->bytes = size;
    fprintf(stderr, "GPU initialized: %s; allocated %" PRIu64 " MiB in %zu segments (256 MiB max each).\n",
            name, size / (1024 * 1024), g->count);
    return 0;
fail:
    gpu_destroy(g); return -1;
}

/* Per-thread stacks must stay resident even under swap pressure. */
#define LOCKED_STACK_SIZE (1024u*1024u)
static int start_locked_thread(pthread_t *thread, void *(*fn)(void *), void *arg,
                               void **stack_out) {
    *stack_out = NULL;
    void *stack = NULL;
    if (posix_memalign(&stack, 4096, LOCKED_STACK_SIZE) != 0 || !stack) return ENOMEM;
    memset(stack, 0, LOCKED_STACK_SIZE);
    if (mlock(stack, LOCKED_STACK_SIZE) != 0) {
        int error = errno; free(stack); return error;
    }
    pthread_attr_t attr;
    int err = pthread_attr_init(&attr);
    if (!err) {
        err = pthread_attr_setstack(&attr, stack, LOCKED_STACK_SIZE);
        if (!err) err = pthread_create(thread, &attr, fn, arg);
        pthread_attr_destroy(&attr);
    }
    if (err) { munlock(stack, LOCKED_STACK_SIZE); free(stack); return err; }
    *stack_out = stack;
    return 0;
}
static void free_locked_stack(void *stack) {
    if (stack) { munlock(stack, LOCKED_STACK_SIZE); free(stack); }
}

struct nbd_thread_args { int fd; int status; };
static void *nbd_thread(void *v) {
    struct nbd_thread_args *a = v;
    a->status = ioctl(a->fd, NBD_DO_IT);
    if (a->status < 0 && !stop_requested) perror("NBD_DO_IT");
    return NULL;
}

static int dev_is_free(const char *dev) {
    const char *base = strrchr(dev, '/');
    if (!base || strncmp(dev, "/dev/nbd", 8)) return 0;
    const char *n = dev + 8;
    if (!*n) return 0;
    for (const char *p = n; *p; p++) if (*p < '0' || *p > '9') return 0;
    char path[128];
    snprintf(path, sizeof path, "/sys/block/nbd%s/pid", n);
    struct stat st;
    if (stat(dev, &st) != 0 || !S_ISBLK(st.st_mode)) {
        fprintf(stderr, "%s is not a valid block device.\n", dev);
        return 0;
    }
    /* Refuse a device mounted in our namespace, including bind mounts.
     * Other namespaces and child partitions still require operator checks. */
    /* Device must be 0B before a fresh NBD connection is attached. */
    char sizepath[128];
    snprintf(sizepath, sizeof sizepath, "/sys/block/nbd%s/size", n);
    uint64_t sectors = 0;
    if (!read_u64_sysfs(sizepath, &sectors) || sectors != 0) {
        fprintf(stderr, "%s capacity not zero or unavailable, refusing.\n", dev);
        return 0;
    }
    FILE *mounts = fopen("/proc/self/mountinfo", "r");
    if (mounts) {
        char line[4096];
        unsigned int maj = major(st.st_rdev), min = minor(st.st_rdev);
        while (fgets(line, sizeof line, mounts)) {
            unsigned int m1=0, m2=0;
            if (sscanf(line, "%*u %*u %u:%u", &m1, &m2) == 2 && m1 == maj && m2 == min) {
                fclose(mounts);
                fprintf(stderr, "%s appears mounted; refusing.\n", dev);
                return 0;
            }
        }
        fclose(mounts);
    }
    FILE *f = fopen(path, "r");
    if (f) {
        char data[128];
        if (fgets(data, sizeof data, f)) { fclose(f); fprintf(stderr, "%s already connected (pid %s)", dev, data); return 0; }
        fclose(f);
    }
    f = fopen("/proc/swaps", "r");
    if (f) {
        char line[512];
        while (fgets(line, sizeof line, f)) {
            if (strncmp(line, dev, strlen(dev)) == 0 && (line[strlen(dev)] == ' ' || line[strlen(dev)] == '\t')) {
                fclose(f); fprintf(stderr, "%s is active swap, refusing.\n", dev); return 0;
            }
        }
        fclose(f);
    }
    return 1;
}

static int serve(int fd, struct gpu *g, const char *device) {
    uint8_t *buf = NULL;
    if (posix_memalign((void **)&buf, 4096, MAX_IO) != 0 || !buf) {
        fprintf(stderr, "Unable to allocate aligned I/O buffer.\n");
        return -1;
    }
    memset(buf, 0, MAX_IO);
    if (mlock(buf, MAX_IO) != 0) {
        perror("mlock I/O buffer (refusing to run without locked I/O buffer)");
        free(buf);
        return -1;
    }
    log_event("serve_ready", (uint64_t)g->bytes);
    fprintf(stderr, "%s\n", swap_experiment ?
        "WARNING: Experimental real SWAP enabled by explicit risk flags. GPU/NBD crash may lose swap pages." :
        "RAW BLOCK ONLY. DO NOT SWAPON without the explicitly enabled experiment mode.");
    int result = 0;
    struct io_stats stats = {0};
    uint64_t last_heartbeat = 0;
    while (true) {
        last_phase = 10;
        struct timespec now = {0};
        if (clock_gettime(CLOCK_MONOTONIC, &now) == 0 &&
            (uint64_t)now.tv_sec >= last_heartbeat + 5) {
            last_heartbeat = (uint64_t)now.tv_sec;
            log_event("heartbeat_reads", stats.reads);
            log_event("heartbeat_writes", stats.writes);
            log_event("heartbeat_errors", stats.errors);
        }
        if (stop_requested) {
            if (swap_is_active(device)) {
                fprintf(stderr, "REFUSING shutdown: %s is active swap. Run 'sudo swapoff %s' in another terminal FIRST.\n", device, device);
                stop_requested = 0;
            } else {
                break;
            }
        }
        struct pollfd pfd = { .fd = fd, .events = POLLIN };
        int ready = poll(&pfd, 1, 1000);
        if (ready < 0) {
            if (errno == EINTR) continue;
            perror("poll NBD"); result = -1; break;
        }
        if (ready == 0) continue;
        if (pfd.revents & (POLLERR | POLLNVAL)) { result = -1; break; }
        atomic_fetch_add_explicit(&nbd_request_sequence, 1, memory_order_relaxed);
        atomic_store(&nbd_request_phase, 11);
        atomic_store_explicit(&nbd_request_start_ns, monotonic_ns(), memory_order_release);
        struct nbd_request request;
        last_phase = 11;
        if (recv_all(fd, &request, sizeof request)) break;
        if (ntohl(request.magic) != MAGIC_REQ) { fprintf(stderr, "Invalid NBD request magic.\n"); result = -1; break; }
        uint32_t full_type = ntohl(request.type);
        uint32_t opcode = full_type & 0xffffu;
        last_opcode = (sig_atomic_t)opcode;
        uint32_t length = ntohl(request.len);
        uint64_t offset = be64(request.from);
        int err = nopen_validate_request(full_type, offset, length,
                                         g->bytes, MAX_IO, BLKSIZE);
        if (opcode == NBD_CMD_DISC && !err) {
            if (swap_is_active(device)) {
                /* Refusing to intentionally disconnect while swap is mounted.
                 * This does not prevent kernel forcibly detaching on SIGBUS. */
                err = EBUSY;
            } else break;
        }
        struct nbd_reply reply = {0};
        reply.magic = htonl(MAGIC_REP);
        memcpy(reply.handle, request.handle, sizeof reply.handle);
        /* WRITE always carries its payload before the reply, even if invalid.
         * Drain invalid requests to preserve protocol framing. */
        if (opcode == NBD_CMD_WRITE) {
            if (err) {
                if (drain_write_payload(fd, buf, length)) { result = -1; break; }
            } else {
                last_phase = 12;
                atomic_store(&nbd_request_phase, 12);
                if (recv_all(fd, buf, length)) { result = -1; break; }
                last_phase = 13;
                atomic_store(&nbd_request_phase, 13);
                if (gpu_transfer(g, true, offset, length, buf)) err = EIO;
                else { stats.writes++; stats.write_bytes += length; }
            }
        } else if (opcode == NBD_CMD_READ && !err) {
            last_phase = 14;
            atomic_store(&nbd_request_phase, 14);
            if (gpu_transfer(g, false, offset, length, buf)) err = EIO;
            else { stats.reads++; stats.read_bytes += length; }
        } else if (opcode == NBD_CMD_FLUSH && !err) {
            last_phase = 15;
            atomic_store(&nbd_request_phase, 15);
            if (clFinish(g->queue) != CL_SUCCESS) err = EIO;
            else stats.flushes++;
        }
        if (err) {
            stats.errors++;
            log_event("nbd_error", (uint64_t)(uint32_t)err);
            fprintf(stderr, "NBD request error opcode=%u off=%" PRIu64
                    " len=%u err=%d\n", opcode, offset, length, err);
        }
        last_phase = 16;
        atomic_store(&nbd_request_phase, 16);
        reply.error = htonl((uint32_t)err);
        if (send_all(fd, &reply, sizeof reply)) { result = -1; break; }
        if (opcode == NBD_CMD_READ && !err && send_all(fd, buf, length)) { result = -1; break; }
        atomic_store_explicit(&nbd_request_start_ns, 0, memory_order_release);
    }
    log_event("serve_exit", (uint64_t)(uint32_t)(result ? 1 : 0));
    fprintf(stderr, "I/O stats: reads=%" PRIu64 " writes=%" PRIu64
            " flushes=%" PRIu64 " read_bytes=%" PRIu64
            " write_bytes=%" PRIu64 " errors=%" PRIu64 "\n",
            stats.reads, stats.writes, stats.flushes,
            stats.read_bytes, stats.write_bytes, stats.errors);
    fprintf(stderr, "GPU chunk max latency=%" PRIu64 " us, >=250ms chunks=%" PRIu64 "\n",
            max_gpu_io_us, slow_gpu_io_count);
    munlock(buf, MAX_IO);
    free(buf);
    return result;
}

int main(int argc, char **argv) {
    if (!((argc == 5 || argc == 7) && !strcmp(argv[1], "--device") &&
          !strcmp(argv[3], "--mib"))) {
        fprintf(stderr, "Usage: sudo %s --device /dev/nbd15 --mib 2048 [--swap-experiment --accept-crash-risk]\n", argv[0]);
        return 2;
    }
    if (argc == 7) {
        if (strcmp(argv[5], "--swap-experiment") || strcmp(argv[6], "--accept-crash-risk")) {
            fprintf(stderr, "Invalid experiment flags.\n"); return 2;
        }
        swap_experiment = true;
    }
    char *end = NULL;
    unsigned long mb = strtoul(argv[4], &end, 10);
    if (!*argv[4] || !end || *end || mb != 2048 || strcmp(argv[2], "/dev/nbd15") || !dev_is_free(argv[2])) {
        fprintf(stderr, "Requires a FREE /dev/nbd15 with --mib 2048 (2 GiB).\n"); return 2;
    }
    if (geteuid() != 0) { fprintf(stderr, "Need root for NBD ioctls.\n"); return 2; }
    if (mlockall(MCL_CURRENT) != 0) {
        perror("mlockall(MCL_CURRENT)");
        fprintf(stderr, "Refusing to start without locked current pages.\n");
        return 1;
    }
    install_fault_logging();
    log_event("boot_mib", mb);
    log_event("experiment_enabled", swap_experiment ? 1 : 0);
    uint64_t bytes = (uint64_t)mb * 1024u * 1024u;
    fprintf(stderr, "Nopen v0.9.2: 2048 MiB %s.\n",
            swap_experiment ? "HIGH RISK REAL SWAP CANARY" : "RAW BLOCK TEST");
    print_gpu_memory("before");
    if (pre_gpu_vram_free && bytes + 4ull*1024*1024*1024 > pre_gpu_vram_free) {
        fprintf(stderr,"Not enough free VRAM to preserve >=4 GiB GPU headroom. Refusing.\n");
        return 2;
    }
    signal(SIGPIPE, SIG_IGN);
    struct sigaction sa = {0}; sa.sa_handler = stop_signal;
    sigemptyset(&sa.sa_mask); sigaction(SIGINT, &sa, NULL); sigaction(SIGTERM, &sa, NULL);
    struct gpu gpu = {0};
    if (gpu_init(&gpu, bytes)) return 1;
    print_gpu_memory("after");
    log_event("gpu_ready_mib",mb);
    /* v0.9.2: do NOT mlockall() after clCreateBuffer(). OpenCL maps GPU
     * objects and may reserve multi-GiB virtual ranges; v0.9 locked those
     * ranges (VmLck was 4.31 GiB), while RSS was only ~271 MiB.
     * Current CPU code/stack was locked before OpenCL initialization.
     * Explicitly lock the I/O buffer and both auxiliary thread stacks. */
    log_event("post_gpu_global_mlock_skipped", 1);
    uint64_t locked_kib = 0;
    FILE *statf = fopen("/proc/self/status", "r");
    if (!statf) {
        perror("/proc/self/status"); gpu_destroy(&gpu); return 1;
    }
    char statline[256];
    bool found_locked = false;
    while (fgets(statline, sizeof statline, statf)) {
        if (sscanf(statline, "VmLck: %" SCNu64 " kB", &locked_kib) == 1) {
            found_locked = true; break;
        }
    }
    fclose(statf);
    if (!found_locked || locked_kib > 512ull*1024ull) {
        fprintf(stderr,"REFUSED: initial VmLck=%" PRIu64 " KiB (limit 524288 KiB).\n", locked_kib);
        log_event("refuse_vmlck_kib", locked_kib);
        gpu_destroy(&gpu); return 1;
    }
    fprintf(stderr,"v0.9.2 before worker threads: VmLck=%" PRIu64 " KiB (v0.9 saw ~4.31 GiB).\n", locked_kib);
    log_event("vmlck_kib", locked_kib);
    int nbd = open(argv[2], O_RDWR | O_CLOEXEC);
    if (nbd < 0) { perror("open NBD device"); gpu_destroy(&gpu); return 1; }
    int sv[2];
    if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, sv)) { perror("socketpair"); close(nbd); gpu_destroy(&gpu); return 1; }
    if (ioctl(nbd, NBD_SET_BLKSIZE, BLKSIZE) < 0 ||
        ioctl(nbd, NBD_SET_SIZE_BLOCKS, (unsigned long)(bytes / BLKSIZE)) < 0 ||
        ioctl(nbd, NBD_SET_TIMEOUT, 60ul) < 0 ||
        ioctl(nbd, NBD_SET_FLAGS, NBD_FLAG_HAS_FLAGS | NBD_FLAG_SEND_FLUSH) < 0 ||
        ioctl(nbd, NBD_SET_SOCK, sv[1]) < 0) {
        perror("NBD ioctl setup"); close(sv[0]); close(sv[1]); close(nbd); gpu_destroy(&gpu); return 1;
    }
    struct nbd_thread_args args = {.fd = nbd, .status = -1};
    pthread_t worker, watcher;
    void *worker_stack = NULL, *watcher_stack = NULL;
    int thread_error = start_locked_thread(&worker, nbd_thread, &args, &worker_stack);
    if (thread_error != 0) {
        fprintf(stderr, "Cannot start locked NBD thread: %s\n", strerror(thread_error));
        ioctl(nbd, NBD_CLEAR_SOCK); close(sv[0]); close(sv[1]); close(nbd); gpu_destroy(&gpu); return 1;
    }
    thread_error = start_locked_thread(&watcher, gpu_watchdog, NULL, &watcher_stack);
    if (thread_error != 0) {
        fprintf(stderr, "Cannot start locked watchdog thread: %s\n", strerror(thread_error));
        stop_requested = 1;
        ioctl(nbd, NBD_DISCONNECT);
        shutdown(sv[0], SHUT_RDWR); shutdown(sv[1], SHUT_RDWR);
        pthread_join(worker,NULL); free_locked_stack(worker_stack);
        ioctl(nbd,NBD_CLEAR_SOCK); close(sv[0]); close(sv[1]); close(nbd);
        gpu_destroy(&gpu); return 1;
    }
    log_event("locked_thread_stacks_bytes", 2ull*LOCKED_STACK_SIZE);
    fprintf(stderr, "Nopen VRAM-NBD v0.9.2 (2048 MiB MEMLOCK + WATCHDOG EXPERIMENTAL).\n");
    fprintf(stderr, "READY %s: %lu MiB backed by AMD OpenCL.\n", argv[2], mb);
    fprintf(stderr, "Crash log: /var/log/nopen-vram-nbd-v092.log\n");
    snapshot_maps();
    last_phase = 9;
    int r = serve(sv[0], &gpu, argv[2]);
    /* The NBD backend MUST NOT detach while its pages are still active swap. */
    if (swap_is_active(argv[2])) {
        fprintf(stderr, "CRITICAL: NBD service ended while %s remains active swap.\n", argv[2]);
        fprintf(stderr, "Manual recovery required; trying to retain connection until swapoff.\n");
        while (swap_is_active(argv[2])) sleep(1);
    }
    /* Interrupt kernel-side NBD handler and release the device. */
    stop_requested = 1;
    ioctl(nbd, NBD_DISCONNECT);
    shutdown(sv[0], SHUT_RDWR);
    shutdown(sv[1], SHUT_RDWR);
    close(sv[0]); close(sv[1]);
    pthread_join(worker, NULL);
    atomic_store(&watchdog_shutdown, true);
    pthread_join(watcher, NULL);
    free_locked_stack(watcher_stack);
    free_locked_stack(worker_stack);
    ioctl(nbd, NBD_CLEAR_QUE);
    ioctl(nbd, NBD_CLEAR_SOCK);
    close(nbd);
    last_phase = 18;
    gpu_destroy(&gpu);
    log_event("normal_exit", 0);
    if (crash_log_fd >= 0) close(crash_log_fd);
    if (alt_stack_memory) munmap(alt_stack_memory,64u*1024u);
    fprintf(stderr, "NBD detached and VRAM released.\n");
    return r ? 1 : 0;
}
