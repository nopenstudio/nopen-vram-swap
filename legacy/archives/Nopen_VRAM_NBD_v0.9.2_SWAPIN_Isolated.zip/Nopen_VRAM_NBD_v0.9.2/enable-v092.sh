#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
DEV=/dev/nbd15
if ! systemctl -q is-active nopen-vram-v092.service; then echo 'v0.9.2 systemd service is NOT active; run ./start-v092.sh' >&2; exit 1; fi
if [[ ! -f /sys/block/nbd15/pid ]] || [[ $(sudo blockdev --getsize64 "$DEV") != 2147483648 ]]; then echo 'NBD15 not 2 GiB or not connected' >&2; exit 1; fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then echo 'Already active swap. Nothing to do.'; swapon --show; exit 0; fi
if findmnt -rn --source "$DEV" | grep -q .; then echo 'Device is mounted; refusing' >&2; exit 1; fi
exe=$(readlink -f ./nopen-vram-nbd)
found=0
while read -r pid; do
    [[ -r /proc/$pid/cmdline ]] || continue
    path=$(sudo readlink -f "/proc/$pid/exe" 2>/dev/null || true)
    cmd=$(sudo tr '\0' ' ' <"/proc/$pid/cmdline" 2>/dev/null || true)
    if [[ "$path" == "$exe" && "$cmd" == *'--mib 2048 --swap-experiment --accept-crash-risk'* ]]; then found=1; break; fi
done < <(pgrep -x nopen-vram-nbd || true)
if (( !found )); then echo 'No matching v0.9.2 experimental backend; refusing.' >&2; exit 1; fi
printf '%s\n' '' 'CRITICAL WARNING: v0.5 caused SIGBUS, destroyed swap pages and crashed the desktop.' \
'v0.9.2 is NOT certified safe. The GPU backend can crash and you may lose unsaved data.' \
'This action overwrites /dev/nbd15 with a swap signature, NOT any NVMe device.' \
'Save work and DO NOT test under irreplaceable workloads.'
read -r -p 'Type EXACTLY EVET SIGBUS RISKI to enable GPU SWAP: ' answer
[[ "$answer" == 'EVET SIGBUS RISKI' ]] || { echo Cancelled; exit 1; }
if ! systemctl -q is-active nopen-vram-v092-monitor.service; then
  sudo systemd-run --unit=nopen-vram-v092-monitor --description='Nopen v0.9.2 persistent memory/GPU telemetry' --collect \
      --property=Type=simple --property=Restart=no --property=StandardOutput=journal \
      --property=StandardError=journal /usr/bin/bash "$(pwd)/monitor-v092.sh"
fi
sleep 1
if ! systemctl -q is-active nopen-vram-v092-monitor.service; then echo 'Persistent monitor did not start. Refusing swap.' >&2; exit 1; fi
sudo journalctl --sync || true
sudo mkswap -f "$DEV"
if ! systemctl -q is-active nopen-vram-v092.service || [[ ! -s /sys/block/nbd15/pid ]]; then
  echo 'Nopen disconnected during mkswap, refusing swapon.' >&2
  exit 1
fi
sudo swapon -p 200 "$DEV"
echo '=== ACTIVE SWAP, highest priority FIRST ==='
swapon --show
printf '%s\n' 'After play, close the game, run ./disable-v092.sh, and ONLY THEN stop the Nopen backend.'
