# Changes — v0.9.2
- Adds NBD request latency watchdog independent from the OpenCL transfer timer (logging only).
- Adds optional strict cgroup-v2 memory.max / memory.swap.max gate to real-swap-cycle test.
- Adds `run-isolated-cycle.sh`: 1536 MiB two-cycle test under MemoryMax=768M and MemorySwapMax=1800M, with no global memory-fill.
- Records cgroup memory and swap usage/events at swap-out and swap-in checkpoints.
- Keeps v0.9.1a swapserver architecture and its known fatal stability risks; no claim of SIGBUS fix.
