#!/usr/bin/env python3
"""Controlled *real Linux swap* page-in / page-out integrity test.

THIS DOES NOT MAKE VRAM CPU-ADDRESSABLE RAM. It tests anonymous pages that
Linux's VM may swap to Nopen's higher-priority NBD-backed VRAM device.
Requires an already active, higher-priority /dev/nbd15 swap; never calls
mkswap, swapon or swapoff itself. Do not run on a production system.
"""
import argparse
import hashlib
import json
import mmap
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

PAGE = os.sysconf("SC_PAGE_SIZE")
MIB = 1024 * 1024
VRAM_SWAP = "/dev/nbd15"
ZRAM = "/dev/zram0"
MADV_PAGEOUT = getattr(mmap, "MADV_PAGEOUT", 21)  # linux/include/uapi/asm-generic/mman-common.h
PATTERN_COUNT = 256
ISOLATED_CGROUP = False


def cgroup_memory():
    """Read ONLY this process's cgroup-v2 limits; never change host limits."""
    if not Path('/sys/fs/cgroup/cgroup.controllers').exists():
        raise RuntimeError('Requires cgroup v2 for isolated page-in test')
    cgroup = None
    for line in Path('/proc/self/cgroup').read_text().splitlines():
        if line.startswith('0::'):
            cgroup = line[3:]
            break
    if cgroup is None:
        raise RuntimeError('Cannot find own memory cgroup')
    root = Path('/sys/fs/cgroup').resolve()
    path = (root / cgroup.lstrip('/')).resolve()
    if not path.is_relative_to(root):
        raise RuntimeError('Invalid cgroup path')
    def read(name):
        try:
            return (path / name).read_text().strip()
        except OSError:
            return None
    return {'path': str(path), 'memory.max': read('memory.max'),
            'memory.current': read('memory.current'),
            'memory.swap.max': read('memory.swap.max'),
            'memory.swap.current': read('memory.swap.current'),
            'memory.events': read('memory.events')}


def check_isolation(memory_mib):
    cg = cgroup_memory()
    lim = cg['memory.max']
    swaplim = cg['memory.swap.max']
    if lim is None or not lim.isdigit() or int(lim) > 896*MIB:
        raise RuntimeError('Isolated test requires a cgroup memory.max <=896 MiB (run ./run-isolated-cycle.sh)')
    if swaplim is None or not swaplim.isdigit() or int(swaplim) > 2048*MIB:
        raise RuntimeError('Isolated test requires memory.swap.max <=2048 MiB')
    if int(swaplim) < memory_mib * MIB:
        raise RuntimeError('Swap limit smaller than requested workload; choose a smaller test')
    if int(lim) >= memory_mib*MIB:
        raise RuntimeError('memory.max must be less than the test allocation to evict swap cache')
    return cg


def parse_swap():
    entries = {}
    with open("/proc/swaps", encoding="utf-8") as f:
        next(f, None)
        for row in f:
            cols = row.split()
            if len(cols) >= 5:
                entries[cols[0]] = {
                    "size_kib": int(cols[2]), "used_kib": int(cols[3]),
                    "priority": int(cols[4]),
                }
    return entries


def mem_available_mib():
    with open("/proc/meminfo", encoding="utf-8") as f:
        for line in f:
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) / 1024
    return 0.0


def vmstat():
    out = {}
    with open("/proc/vmstat", encoding="utf-8") as f:
        for line in f:
            tok = line.split()
            if len(tok) == 2 and tok[0] in ("pswpin", "pswpout"):
                out[tok[0]] = int(tok[1])
    return out


def swap_cached_mib():
    with open("/proc/meminfo", encoding="utf-8") as f:
        for line in f:
            if line.startswith("SwapCached:"):
                return int(line.split()[1]) / 1024
    return 0.0


def nbd_disk_stats():
    # /sys/block/<device>/stat: sectors are always 512-byte units.
    # Reads may include unrelated system I/O; use together with process counters.
    path = Path("/sys/block/nbd15/stat")
    fields = [int(x) for x in path.read_text(encoding="ascii").split()]
    if len(fields) < 7:
        raise RuntimeError("NBD disk counters unavailable")
    return {"read_ios": fields[0], "read_mib": fields[2] / 2048,
            "write_ios": fields[4], "write_mib": fields[6] / 2048}


def self_major_faults():
    # /proc/self/stat contains an arbitrary process name in parentheses.
    text = Path("/proc/self/stat").read_text(encoding="ascii")
    after_comm = text.rsplit(") ", 1)[1].split()
    # majflt is field #12, here index 9 because state is field #3.
    return int(after_comm[9])


def vmswap_mib():
    with open("/proc/self/status", encoding="utf-8") as f:
        for line in f:
            if line.startswith("VmSwap:"):
                return int(line.split()[1]) / 1024
    return 0.0


def check_swap(min_available=0):
    swaps = parse_swap()
    nbd = swaps.get(VRAM_SWAP)
    zram = swaps.get(ZRAM)
    if not nbd or not zram:
        raise RuntimeError("Requires BOTH /dev/nbd15 and /dev/zram0 active SWAP")
    if set(swaps) != {VRAM_SWAP, ZRAM}:
        raise RuntimeError("Unexpected additional swap area: " + ", ".join(sorted(set(swaps) - {VRAM_SWAP, ZRAM})))
    if nbd["size_kib"] < 2 * 1024 * 1024 - 8192:
        raise RuntimeError("/dev/nbd15 is not a 2 GiB swap device")
    if nbd["priority"] <= zram["priority"]:
        raise RuntimeError("VRAM swap priority MUST exceed ZRAM priority")
    if not Path("/sys/block/nbd15/pid").exists():
        raise RuntimeError("NBD backend disconnected")
    r = subprocess.run(["systemctl", "is-active", "--quiet", "nopen-vram-v092.service"],
                       check=False, timeout=5)
    if r.returncode:
        raise RuntimeError("v0.9.2 systemd backend service is NOT running")
    avail = mem_available_mib()
    if avail < min_available:
        raise RuntimeError(f"Low MemAvailable {avail:.0f} MiB (required {min_available} MiB)")
    return {"swaps": swaps, "mem_available_mib": round(avail, 1), "vmstat": vmstat(),
            "self_vmswap_mib": round(vmswap_mib(), 1),
            "swap_cached_mib": round(swap_cached_mib(), 1),
            "nbd_disk": nbd_disk_stats(),
            "self_major_faults": self_major_faults()}


def page_pool(cycle):
    blocks = []
    for i in range(PATTERN_COUNT):
        digest = hashlib.blake2b(f"Nopen-v091:{cycle}:{i}".encode(), digest_size=64).digest()
        blocks.append(digest * (PAGE // 64))
    return blocks


def page_pattern(pool, page_num, cycle):
    # Unique 16-byte tag at both ends detects misdirected page loads.
    tag = struct.pack("<QQ", page_num, (cycle << 32) ^ 0x4E4F50454E303931)
    template = pool[(page_num * 137 + cycle * 11) % PATTERN_COUNT]
    return tag + template[16:-16] + tag


class Recorder:
    def __init__(self, directory):
        directory.mkdir(parents=True, exist_ok=True)
        os.chmod(directory, 0o700)
        self.path = directory / "events.jsonl"
        self.f = self.path.open("a", encoding="utf-8", buffering=1)

    def write(self, phase, **data):
        obj = {"clock": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
               "monotonic": round(time.monotonic(), 3), "phase": phase, **data}
        self.f.write(json.dumps(obj, sort_keys=True) + "\n")
        self.f.flush()
        os.fsync(self.f.fileno())
        extra = " ".join(f"{k}={v}" for k, v in data.items())
        print(f"[{phase}] {extra}", flush=True)

    def close(self):
        self.f.close()


def run_cycle(rec, memory, mib, chunk_mib, cycle, min_available):
    chunks = mib // chunk_mib
    pages_per_chunk = chunk_mib * MIB // PAGE
    pool = page_pool(cycle)
    start_stats = check_swap(min_available)
    rec.write("cycle_start", cycle=cycle, vram_swap_used_mib=round(start_stats["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1),
              available_mib=start_stats["mem_available_mib"])
    t0 = time.monotonic()
    for chunk in range(chunks):
        begin = chunk * chunk_mib * MIB
        first_page = begin // PAGE
        for p in range(pages_per_chunk):
            page_num = first_page + p
            at = begin + p * PAGE
            memory[at:at + PAGE] = page_pattern(pool, page_num, cycle)
        # MADV_PAGEOUT (21) is Linux's VM reclaim request for anonymous pages.
        # It may partially fail to swap pages; independent stats prove activity.
        memory.madvise(MADV_PAGEOUT, begin, chunk_mib * MIB)
        if (chunk + 1) % max(1, (256 // chunk_mib)) == 0 or chunk + 1 == chunks:
            status = check_swap(min_available)
            rec.write("filled_and_pageout", cycle=cycle, done_mib=(chunk+1)*chunk_mib,
                      nbd_used_mib=round(status["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1),
                      zram_used_mib=round(status["swaps"][ZRAM]["used_kib"] / 1024, 1),
                      self_vmswap_mib=status["self_vmswap_mib"],
                      available_mib=status["mem_available_mib"])
    t_out = time.monotonic() - t0
    time.sleep(1)
    paged = check_swap(min_available)
    delta_out = paged["vmstat"].get("pswpout", 0) - start_stats["vmstat"].get("pswpout", 0)
    # Require actual Linux swap OUT counters, not simply a successful mmap write.
    if delta_out < int((mib * MIB // PAGE) * 0.5):
        raise RuntimeError(f"Insufficient actual pageout: {delta_out} pages, expected >=50% of {mib} MiB. Test NOT validated")
    vram_used_increase = (paged["swaps"][VRAM_SWAP]["used_kib"] -
                          start_stats["swaps"][VRAM_SWAP]["used_kib"]) / 1024
    if vram_used_increase < mib * 0.5:
        raise RuntimeError(f"Only {vram_used_increase:.0f} MiB increased on VRAM-SWAP; must confirm >=50% on /dev/nbd15")
    rec.write("pageout_confirmed", cycle=cycle, pswpout_pages=delta_out,
              self_vmswap_mib=paged["self_vmswap_mib"],
              swap_cached_mib=paged["swap_cached_mib"],
              nbd_read_mib=paged["nbd_disk"]["read_mib"],
              nbd_used_mib=round(paged["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1),
              vram_swap_increase_mib=round(vram_used_increase, 1),
              seconds=round(t_out, 2),
              cgroup_memory=cgroup_memory() if ISOLATED_CGROUP else None)
    t1 = time.monotonic()
    # Read in reverse 64 MiB chunks to exercise non-sequential page faults.
    for n, chunk in enumerate(range(chunks - 1, -1, -1)):
        begin = chunk * chunk_mib * MIB
        first_page = begin // PAGE
        for p in range(pages_per_chunk - 1, -1, -1):
            page_num = first_page + p
            at = begin + p * PAGE
            observed = memory[at:at + PAGE]
            if observed != page_pattern(pool, page_num, cycle):
                rec.write("DATA_CORRUPTION", cycle=cycle, page=page_num, offset=at,
                          observed_tag=observed[:16].hex())
                raise RuntimeError(f"Data corruption at page {page_num} / offset {at}")
        if (n + 1) % max(1, (256 // chunk_mib)) == 0 or n + 1 == chunks:
            status = check_swap(min_available)
            rec.write("pagein_verified", cycle=cycle, verified_mib=(n+1)*chunk_mib,
                      nbd_used_mib=round(status["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1),
                      available_mib=status["mem_available_mib"])
    read_seconds = time.monotonic() - t1
    end = check_swap(min_available)
    delta_in = end["vmstat"].get("pswpin", 0) - paged["vmstat"].get("pswpin", 0)
    nbd_read_delta = end["nbd_disk"]["read_mib"] - paged["nbd_disk"]["read_mib"]
    majflt_delta = end["self_major_faults"] - paged["self_major_faults"]
    rec.write("pagein_counters", cycle=cycle, pswpin_pages=delta_in,
              nbd_read_delta_mib=round(nbd_read_delta, 3),
              major_fault_delta=majflt_delta,
              self_vmswap_before_mib=paged["self_vmswap_mib"],
              self_vmswap_after_mib=end["self_vmswap_mib"],
              swap_cached_before_mib=paged["swap_cached_mib"],
              swap_cached_after_mib=end["swap_cached_mib"],
              swap_used_before_mib=round(paged["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1),
              swap_used_after_mib=round(end["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1),
              cgroup_memory=cgroup_memory() if ISOLATED_CGROUP else None)
    # Correct data alone does not prove reads reached GPU; swapcache might
    # satisfy faults without a physical NBD read. Never call this a full pass.
    if delta_in < int((mib * MIB // PAGE) * 0.5) or nbd_read_delta < mib * 0.5:
        rec.write("INCONCLUSIVE_SWAPIN", cycle=cycle,
                  reason="Data matched, but device page-in was not sufficiently observed; swap cache is a possible cause")
        return False
    rec.write("cycle_pass", cycle=cycle, verified_mib=mib,
              pswpin_pages=delta_in, pswpout_pages=delta_out,
              pageout_seconds=round(t_out, 2), pagein_seconds=round(read_seconds, 2),
              nbd_used_mib=round(end["swaps"][VRAM_SWAP]["used_kib"] / 1024, 1))
    return True


def self_test():
    if PAGE != 4096:
        raise RuntimeError(f"Unexpected page size {PAGE}")
    with mmap.mmap(-1, 8*MIB, flags=mmap.MAP_PRIVATE|mmap.MAP_ANONYMOUS,
                   prot=mmap.PROT_READ|mmap.PROT_WRITE) as mem:
        pool = page_pool(1)
        for page in range((8*MIB)//PAGE):
            pos = page*PAGE
            mem[pos:pos+PAGE] = page_pattern(pool, page, 1)
        for page in reversed(range((8*MIB)//PAGE)):
            pos = page*PAGE
            assert mem[pos:pos+PAGE] == page_pattern(pool, page, 1)
        mem[PAGE:PAGE+16] = b"X"*16
        assert mem[PAGE:PAGE+PAGE] != page_pattern(pool, 1, 1)
    print("PASS: 8 MiB anonymous page patterns and corruption detection. NO SWAP USED.", flush=True)


def main():
    ap = argparse.ArgumentParser(description="Nopen v0.9.2 instrumented real Linux swap cycle (HIGH RISK)")
    ap.add_argument("--mib", type=int, default=1536, choices=[512, 768, 1024, 1280, 1536],
                    help="Anonymous memory to churn; NOT the allocated 2048 MiB GPU capacity")
    ap.add_argument("--cycles", type=int, default=2, choices=[1, 2, 3, 4])
    ap.add_argument("--chunk-mib", type=int, default=64, choices=[16, 32, 64, 128])
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--require-isolated-memory", action="store_true",
                    help="Refuse unless the process runs under a strict cgroup-v2 RAM/swap limit")
    ap.add_argument("--i-accept-crash-risk", action="store_true")
    args = ap.parse_args()
    if args.self_test:
        self_test()
        return 0
    if not sys.platform.startswith("linux") or PAGE != 4096:
        ap.error("Only Linux with 4 KiB pages is supported")
    if args.mib % args.chunk_mib:
        ap.error("--mib must be divisible by --chunk-mib")
    if not args.i_accept_crash_risk:
        ap.error("Requires --i-accept-crash-risk. v0.9.2 may freeze the entire system or lose data")
    global ISOLATED_CGROUP
    ISOLATED_CGROUP = args.require_isolated_memory
    if args.require_isolated_memory:
        cg = check_isolation(args.mib)
        print('[MEMCG VERIFIED] ' + json.dumps(cg), flush=True)
    start_state = check_swap(min_available=3072)
    if start_state["swaps"][VRAM_SWAP]["used_kib"] > 128*1024:
        raise RuntimeError("VRAM swap already >128 MiB used; close other workloads first")
    folder = Path(__file__).resolve().parent / "test-runs" / time.strftime("swap-cycle-%Y%m%d-%H%M%S")
    recorder = Recorder(folder)
    recorder.write("start", mib=args.mib, cycles=args.cycles, chunk_mib=args.chunk_mib,
                   nbd_priority=start_state["swaps"][VRAM_SWAP]["priority"],
                   zram_priority=start_state["swaps"][ZRAM]["priority"],
                   swap_before=start_state["swaps"],
                   memory_cgroup=cgroup_memory() if args.require_isolated_memory else None)
    mem = None
    try:
        mem = mmap.mmap(-1, args.mib*MIB,
                        flags=mmap.MAP_PRIVATE | mmap.MAP_ANONYMOUS,
                        prot=mmap.PROT_READ | mmap.PROT_WRITE)
        for cycle in range(1, args.cycles+1):
            confirmed = run_cycle(recorder, mem, args.mib, args.chunk_mib, cycle, min_available=1024)
            if not confirmed:
                recorder.write("TEST_INCONCLUSIVE", cycle=cycle,
                               note="Swap-out and byte integrity passed; physical swap-in unproven")
                print("INCONCLUSIVE: GPU swap-out succeeded and bytes matched, but swap-in was not confirmed. See pagein_counters in events.jsonl.", flush=True)
                return 2
        recorder.write("TEST_PASS", mib=args.mib, cycles=args.cycles,
                       swap_after=parse_swap(), vmstat_after=vmstat())
        print(f"PASS: {args.cycles} real Linux pageout/pagein cycles over {args.mib} MiB; logs: {folder}", flush=True)
        return 0
    except BaseException as e:
        recorder.write("ABORT", reason=str(e), error_type=type(e).__name__)
        raise
    finally:
        if mem is not None:
            try:
                mem.close()
            except Exception:
                pass
        recorder.close()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (RuntimeError, OSError, ValueError) as e:
        print(f"FAIL: {e}", file=sys.stderr, flush=True)
        sys.exit(1)
