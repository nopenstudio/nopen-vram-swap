# Nopen VRAM-NBD v0.9.2 (experimental)

AMD OpenCL-backed Linux NBD prototype with a real swap-in test confined to a systemd user cgroup.

**NOT production-safe. Prior experiments caused a desktop crash and a hard hang.**

Features: 2048 MiB GPU-backed block device, optional swap priority 200 above ZRAM priority 100, diagnostics for long GPU/NBD operations, an opt-in 1536 MiB two-cycle anonymous page out/in verification under a 768 MiB test-process memory.max cgroup, durable telemetry, and explicit swapoff before backend teardown. Does **not** reserve CPU-visible RAM or prevent GPU resets. 

See `README_TR.md` for complete runbook.
