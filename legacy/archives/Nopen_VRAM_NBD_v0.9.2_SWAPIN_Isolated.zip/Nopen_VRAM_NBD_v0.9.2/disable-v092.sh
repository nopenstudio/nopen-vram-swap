#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
  echo 'Stopping swap may hang or fail if backend is broken. Close the game first.'
  used=$(awk '$1=="/dev/nbd15" {print $4}' /proc/swaps)
  available=$(awk '$1=="MemAvailable:" {print $2}' /proc/meminfo)
  echo "NBD swap used: ${used:-?} KiB; available RAM: ${available:-?} KiB"
  if [[ ${used:-0} -ge ${available:-0} ]]; then echo 'Insufficient MemAvailable for swapoff. Close other programs first.' >&2; exit 1; fi
  sudo swapoff /dev/nbd15
fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then echo 'SWAP STILL ACTIVE: do not stop backend.' >&2; exit 1; fi
sudo systemctl stop nopen-vram-v092.service || true
sudo systemctl stop nopen-vram-v092-monitor.service || true
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS /dev/nbd15
