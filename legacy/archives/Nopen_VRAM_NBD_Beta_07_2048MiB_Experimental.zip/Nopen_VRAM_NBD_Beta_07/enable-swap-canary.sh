#!/usr/bin/env bash
set -euo pipefail
# High-risk live swap test: do not run unless you accept complete system loss.
DEV=/dev/nbd15
SIZE=2147483648
if [[ ! -b "$DEV" ]]; then echo "HATA: $DEV yok, once sudo modprobe nbd nbds_max=16 max_part=0" >&2; exit 1; fi
if ! [[ -f /sys/block/nbd15/pid && -s /sys/block/nbd15/pid ]]; then echo "HATA: NBD baglantisi bulunamadi." >&2; exit 1; fi
actual=$(sudo blockdev --getsize64 "$DEV")
if [[ "$actual" != "$SIZE" ]]; then echo "HATA: 2048 MiB yerine $actual bayt var." >&2; exit 1; fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then echo "HATA: SWAP zaten aktif." >&2; exit 1; fi
if findmnt -rn --source "$DEV" | grep -q .; then echo "HATA: Aygit bagli." >&2; exit 1; fi
pid=$(pgrep -xo nopen-vram-nbd || true)
if [[ -z "$pid" || ! -r "/proc/$pid/cmdline" ]]; then echo "HATA: Nopen sunucusu bulunamadi." >&2; exit 1; fi
cmd=$(tr '\0' ' ' <"/proc/$pid/cmdline")
if [[ "$cmd" != *'--swap-experiment'* || "$cmd" != *'--accept-crash-risk'* || "$cmd" != *'--mib 2048'* ]]; then
    echo 'HATA: Canli SWAP risk modunda --mib 2048 sunucusu calismiyor.' >&2; exit 1
fi
printf '%s\n' 'UYARI: V0.5 GERCEK SWAP ALTINDA SIGBUS ILE COKTU.' \
 '2 GiB VRAM SWAP ayni sorunu tekrar yasatabilir ve kaydedilmemis verileri kaybettirebilir.' \
 'Bu betik /dev/nbd15 uzerindeki tum verileri siler; ZRAM korunur.' \
 'Once butun calismalarini kaydet. Oyun sunucusunda kararlilik garanti DEGIL.'
read -r -p 'Bu riski kabul edip etkinlestirmek icin tam EVET yaz: ' choice
if [[ "$choice" != EVET ]]; then echo 'Iptal'; exit 1; fi
sudo mkswap -f "$DEV"
sudo swapon --priority 200 "$DEV"
echo 'Etkinlestirme denemesi tamam; durum:'
swapon --show
