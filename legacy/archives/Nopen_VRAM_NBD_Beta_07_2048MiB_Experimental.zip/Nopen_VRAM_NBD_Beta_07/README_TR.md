# Nopen VRAM-NBD v0.7.0 — 2048 MiB Deney

**Durum: Tehlikeli deney / kararlı sürüm değil.** v0.5'in gercek swap testinde `SIGBUS` sonucu NBD baglantisi koptu, swap sayfalari okunamadi. v0.7 bu temel sorunu **cozmus kabul edilmez**.

## Degisiklikler
- Kullanici istegine gore canli swap deneyi **tam 2048 MiB** kapasiteyle sinirlandirildi; 512/1024 MiB onerilmiyor.
- OpenCL veri aktarma parcasi en fazla 1 MiB.
- GPU VRAM kullanim telemetrisi: once/sonra (sistemdeki ilk desteklenen GPU).
- SIGBUS/SIGSEGV logu: `/var/log/nopen-vram-nbd-v07.log`. SA_ONSTACK ile ana thread icin alternatif stack; OpenCL worker threadleri icin garanti yok.
- NBD istek istatistikleri; dusuk bellek durumunda mlock/mmap davranisi kontrolleri.
- `--swap-experiment --accept-crash-risk` olmadan gercek swap modu kullanilmaz. Betik tam onay ister.
- `make test` ile 14 NBD dogrulama birim testi. Programin RX 9060 XT runtime testi **bu ortamda yapilmadi**.

## Derleme
```
make clean && make && make test
sudo modprobe nbd nbds_max=16 max_part=0
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
```
`/dev/nbd15` 0B ve SWAP/MOUNT olmali DEGIL.

## A. Oncelikle 2 GiB ham blok testi (SWAP DEGIL)
Birinci terminal:
```
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 2048
```
Ikinci terminal:
```
sudo python3 test-nbd-2g.py
```
Test basariliysa ilk terminalde Ctrl+C. Bu test 32 x 4 MiB = 128 MiB daginik veri dogrular, 2 GiB'nin tamamini veya aktif SWAP kararliligini kanitlamaz.

## B. ASIRI RISKLI gercek SWAP canary (Sadece ayrica kabul edenler)
Bu adim **sistem kilitlenmesi, grafik oturumunun kapanmasi, veri kaybi** yaratabilir. Onemli veri kaydedilmeden yapilmaz. Daha once ayni sistemde SIGBUS gerceklesti; oyun sunucusu icin guvenilir bir cozum degildir.

Ilk terminal:
```
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 2048 --swap-experiment --accept-crash-risk
```
Ikinci terminal:
```
./enable-swap-canary.sh
```
Bu, **yalnizca dogrulanmis /dev/nbd15** uzerine `mkswap` ve `swapon --priority 200` uygular. ZRAM priority 100 degismez. Hicbir SSD swap olusturulmaz.

Ucuncu terminalden izleme:
```
./monitor-swap.sh
```

Kapatma:
```
./disable-swap-canary.sh
```
`swapoff` basarili olduktan sonra birinci terminalde Ctrl+C. NBD sunucusu etkin swap varken kapanmamalidir. `swapoff` takilirsa sunucuyu zorla oldurme. Sunucu aniden cokerse kayip swap sayfalari geri getirilemeyebilir.

Hata gunlugu:
```
./collect-diagnostics.sh
```

## SINIRLAR
- NBD + GPU kullanan **kullanici alani sureci** bellek baskisi altinda kilitlenebilir veya SIGBUS ile olebilir.
- Linux'un `swapon` basarisi, oyun stabilitesi ya da daha fazla fiziksel RAM anlamina gelmez.
- Fiziksel GPU belleginin yetersizligi, AMD GPU reset, GTT'ye tasma ve OpenCL sureleri arizaya neden olabilir.
- Canli sistemde guvenli deneyin daha guclu yolu ayrik test ortami / kurtarma mekanizmasidir.
- Kaynak kodu ve test betikleri icerir; ikili dosya kullanicinin Linux makinesinde derlenmelidir.
