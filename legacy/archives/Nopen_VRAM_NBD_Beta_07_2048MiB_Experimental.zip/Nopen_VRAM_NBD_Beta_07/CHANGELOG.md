# Changelog

## 0.7.0 experimental
- Honor minimum requested GPU swap canary size: exactly 2048 MiB.
- Cap individual OpenCL transfer segments to 1 MiB.
- Add logging of lifecycle, selected GPU VRAM telemetry and fatal SIGBUS/SIGSEGV signal details.
- Add raw 2 GiB region integrity test and opt-in swap enable/disable scripts.
- Experimental swap remains unsafe and unverified under Bannerlord.
