#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' '==== NOPEN v0.7 LOG ===='
sudo tail -n 100 /var/log/nopen-vram-nbd-v07.log 2>/dev/null || echo 'Kayit yok'
printf '%s\n' '==== NBD/KERNEL ===='
sudo journalctl -k -b --since '30 minutes ago' --no-pager | grep -Ei 'nbd15|amdgpu|GPU reset|oom|bus error|swap|blocked task' | tail -n 100 || true
printf '%s\n' '==== SWAP ===='
swapon --show
printf '%s\n' '==== MEM ===='
free -h
printf '%s\n' '==== GPU SYSFS VRAM ===='
for p in /sys/class/drm/card*/device/mem_info_vram_{total,used}; do
 [[ -r "$p" ]] && printf '%s = %s\n' "$p" "$(cat "$p")"
done
