#!/usr/bin/env bash
set -euo pipefail
DEV=/dev/nbd15
if ! grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
    echo 'nbd15 etkin SWAP degil.'; exit 0
fi
echo 'DIKKAT: swapoff mevcut takas sayfalarini yeniden RAMe alir; GPU NBD arizaliysa takilabilir.'
echo 'Nopen sunucusu ancak basarili swapoff SONRASINDA durdurulmali.'
sudo swapoff "$DEV"
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
    echo 'HATA: SWAP hala aktif. Nopen sunucusunu KAPATMA!' >&2; exit 1
fi
echo 'VRAM SWAP kapandi; simdi sunucu terminalinde Ctrl+C kullanabilirsin.'
swapon --show
