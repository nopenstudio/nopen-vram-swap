#!/usr/bin/env bash
set -euo pipefail
watch -n 1 'date; echo; swapon --show; echo; free -h; echo; cat /proc/pressure/memory'
