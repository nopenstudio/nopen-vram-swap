# Nopen VRAM-NBD v0.8.0 (diagnostic build)

**Experimental AMD OpenCL / Linux NBD GPU-memory-backed block device.**

**Safety status:** raw block I/O only; **DO NOT ENABLE SWAP**. A previous experimental v0.5 swap run terminated with SIGBUS and resulted in missing swap pages and kernel I/O failures. v0.8 has not established a fix.

## Scope

- Exactly 2048 MiB reserved through eight AMD OpenCL buffers.
- NBD read/write/flush servicing; OpenCL subtransfers capped at 1 MiB.
- Fatal SIGBUS/SIGSEGV logging (`/var/log/nopen-vram-nbd-v08.log`) with instruction and fault addresses.
- Memory map snapshot (`/var/log/nopen-vram-nbd-v08.maps`) and slow GPU transfer logging.
- 4 KiB random `O_DIRECT` block data verification; no swap activation tools are distributed.

## Build and test

Requires Linux, an AMD OpenCL platform, NBD kernel module, a C compiler, OpenCL headers and libOpenCL.

```sh
make clean && make && make test
sudo modprobe nbd nbds_max=16 max_part=0
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
```

Only proceed if `/dev/nbd15` is an *unused*, 0-byte NBD device with no active SWAP or mount. In terminal 1:

```sh
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 2048
```

In terminal 2, while NBD is READY:

```sh
sudo python3 test-random4k-direct.py --count 4096
```

This test **destroys test-device data at the selected offsets**. Never point it at real disks. The block test does not establish swap safety, recovery under driver failure or game stability. For shutdown, check that swap is inactive, then press Ctrl+C in terminal 1.

Detailed instructions: [README_TR.md](README_TR.md).

## Root-cause investigation

At 20:49:23 on 2026-10-25, `nopen-vram-nbd` v0.5 died with `SIGBUS` during a real swap experiment. NBD disconnection and read/write failures followed. The initial faulting instruction or library and the trigger for SIGBUS remain unconfirmed. v0.8 seeks to improve the evidence for diagnosis; it does **not** claim to fix the failure.
