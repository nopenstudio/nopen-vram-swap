#!/usr/bin/env bash
set -euo pipefail
printf '\n=== NOPEN V0.8 LOG ===\n'
sudo tail -n 80 /var/log/nopen-vram-nbd-v08.log 2>/dev/null || echo 'No crash log yet'
printf '\n=== KERNEL EVENTS ===\n'
sudo journalctl -k -b --no-pager | grep -Ei 'nbd15|amdgpu|oom|gpu reset|bus error|i/o error' | tail -n 60 || true
printf '\n=== CURRENT SWAP ===\n'
swapon --show
printf '\n=== NOPEN PROCESS ===\n'
ps -eo pid,stat,comm,args | grep '[n]open-vram-nbd' || true
printf '\nNOTE: Logs can include memory addresses and process details.\n'
