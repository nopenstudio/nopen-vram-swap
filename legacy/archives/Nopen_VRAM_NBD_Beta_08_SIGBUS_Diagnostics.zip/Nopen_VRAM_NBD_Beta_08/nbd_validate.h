#ifndef NOPEN_NBD_VALIDATE_H
#define NOPEN_NBD_VALIDATE_H
#include <errno.h>
#include <linux/nbd.h>
#include <stdint.h>

/* Pure NBD request validation; does not touch GPU or device.
 * Keep this independent of OpenCL to allow host-only unit tests.
 * No FUA, TRIM or WRITE_ZEROES are advertised in v0.5.
 */
static inline int nopen_validate_request(uint32_t type, uint64_t offset,
                                          uint32_t length, uint64_t device_bytes,
                                          uint32_t max_io, uint32_t block_size) {
    uint32_t cmd = type & 0xffffu;
    if (type & 0xffff0000u) return EOPNOTSUPP;
    switch (cmd) {
        case NBD_CMD_READ:
        case NBD_CMD_WRITE:
            if (length > max_io) return E2BIG;
            if ((offset % block_size) || (length % block_size)) return EINVAL;
            if (offset > device_bytes || length > device_bytes - offset) return EINVAL;
            return 0;
        case NBD_CMD_FLUSH:
        case NBD_CMD_DISC:
            return (offset || length) ? EINVAL : 0;
        default:
            return EOPNOTSUPP;
    }
}
#endif
