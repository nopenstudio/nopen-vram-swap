# Nopen VRAM-NBD v0.8.0 — SIGBUS Kök Neden Teşhisi

**Durum:** 2048 MiB AMD OpenCL + Linux NBD **ham blok aygıtı**. **Gerçek SWAP'i desteklemez; SWAP testi yapılmamalı.**

## Neden bu sürüm var?

v0.5'te Linux gerçek VRAM-SWAP kullandı, ancak Nopen kullanıcı alanı sunucusu **25 Ekim 2026 20:49:23'te SIGBUS** ile sonlandı. Hemen ardından NBD bağlantısı öldü, swap sayfaları okunamadı ve kernel uyarıları görüldü. `Connection timed out` mesajı birincil neden olarak doğrulanmadı; çöküşle aynı olay zincirinin parçası.

v0.7'de 2048 MiB ayırma ve 128 MiB veri doğrulaması başarıyla tamamlandı, ancak gerçek swap basıncındaki çökme nedeni bilinmiyor.

v0.8, bu hatayı düzeltmiş olduğu iddiasında bulunmaz. Sorunun yerini belirleyecek daha iyi teşhis sunar ve daha gerçekçi ham blok I/O paterni uygular.

## Yenilikler

- v0.7 kaynak kodu temeli, **yalnızca 2048 MiB** ham blok teşhis kapasitesi.
- `SIGBUS/SIGSEGV` yakalandığında `si_code`, `fault_address`, `phase`, `opcode`, `segment`, `block4k`, x86_64 üzerinde `IP` ve `SP` yazılır.
- Hata yakalayıcı, `SA_RESETHAND` ve aynı thread'e sinyal yönlendirerek işletim sisteminin normal coredump yoluna olanak tanır. Coredump yine de dağıtımın limitleri ve politikası yüzünden oluşmayabilir.
- Program başlangıcında `/proc/self/maps` anlık görüntüsü `/var/log/nopen-vram-nbd-v08.maps` dosyasına alınır; ASLR ile dinamik kütüphane konumlarını yorumlamak için.
- OpenCL 1 MiB alt aktarımında gecikme kaydı: 250 ms üzerindeki işlemler günlükte (ilk 20 tanesi), kapanışta azami gecikme ve yavaş işlem sayısı.
- İkinci `mlockall(MCL_CURRENT)` başarısızsa program başlamayı reddeder. Yalnızca bellek kilitlemenin başarısı SWAP güvenliği garantisi değildir.
- `/dev/nbd15` kapasiteli/bağlıyken sunucu başlatılmasını engelleyen kontrol.
- 4096 rastgele seçilmiş 4 KiB konumunda **O_DIRECT** veri yazma ve sonradan okuma testi (varsayılan 16 MiB toplam veri). Kernel page cache etkisini azaltır, ancak tam bir performans ölçümü değildir.

## Kurulum

```
sudo modprobe nbd nbds_max=16 max_part=0
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
```

Başlamadan önce **/dev/nbd15 `0B` olmalı**, aktif SWAP ve mount olmamalı. Eski v0.7 sunucusunu, *SWAP aktif değilken*, ilk terminalinde `Ctrl+C` ile kapat.

```
make clean && make && make test
```

1. terminal:

```
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 2048
```

2. terminal, **yalnızca v0.8 sunucusu READY iken**:

```
sudo python3 test-random4k-direct.py --count 4096
```

Bu test `/dev/nbd15` üzerindeki 4096 adet 4 KiB konumunu **geri döndürülemez biçimde değiştirir**. Sadece boş test aygıtında çalıştır. `mkswap`, `swapon`, disk bölümlendirme, `mkfs` yapılmamalı.

Normal kapatma: SWAP aktif olmadığını tekrar doğrula, ardından sunucu terminalinde `Ctrl+C`.

## Tanılama

```
sudo tail -n 80 /var/log/nopen-vram-nbd-v08.log
sudo journalctl -k -b --no-pager | grep -Ei 'nbd15|amdgpu|oom|bus error|io error' | tail -n 60
```

`NOPEN08 FATAL` kaydı yoksa testte yakalanmış bir SIGBUS/SIGSEGV olmadığı anlamına gelir; hata kök nedeni çözülmüş değildir. Haritaları ve günlüğü gerektiğinde paylaşırken hassas ol; bellek adresleri ve süreç bilgileri içerebilir.

Bir hata kaydında `ip=0x...` varsa ve adres ana ikili dosyadaki bir fonksiyona aitse (v0.8 Linux x86_64 üzerinde `-no-pie` derlenir), adresi incelemek için:

```
addr2line -e ./nopen-vram-nbd -f -C 0xADRES
```

IP bir OpenCL sürücü kütüphanesindeyse önce `v08.maps` ile kütüphane ve offset belirlenmelidir; bu adresi doğrudan `addr2line -e nopen-vram-nbd` ile yorumlamak yanlış olur.

## Bilinen riskler

- v0.5 SIGBUS kök nedeni **henüz bulunmadı**; v0.8 gerçek swap kullanmıyor.
- GPU sürücüsü reset veya yoğun yük altında blok aygıtı kararsız olabilir.
- NBD sunucusu kullanıcı alanındadır; kernel takası altında ölebilmesi, Linux'un kayıp swap sayfalarını geri getirememesi demektir.
- Bu sürüm **oyun için ek RAM veya 2 GiB swap** kazandırmaz.
- Mevcut ZRAM'e dokunulmaz; NVMe üzerinde swap oluşturulmaz.
