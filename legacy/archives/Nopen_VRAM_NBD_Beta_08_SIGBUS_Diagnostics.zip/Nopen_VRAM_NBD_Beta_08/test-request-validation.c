#include "nbd_validate.h"
#include <assert.h>
#include <stdio.h>
#define MB (1024u * 1024u)
#define CAP ((uint64_t)8192 * MB)
#define MX (16u * MB)
#define BLK 4096u
static void check(uint32_t cmd, uint64_t off, uint32_t len, int expect) {
    int actual = nopen_validate_request(cmd, off, len, CAP, MX, BLK);
    if (actual != expect) {
        fprintf(stderr, "FAILED cmd=%u off=%llu len=%u: got=%d expected=%d\n",
                cmd, (unsigned long long)off, len, actual, expect);
        assert(actual == expect);
    }
}
int main(void) {
    check(NBD_CMD_READ, 0, BLK, 0);
    check(NBD_CMD_WRITE, CAP-BLK, BLK, 0);
    check(NBD_CMD_READ, CAP, BLK, EINVAL);
    check(NBD_CMD_WRITE, CAP-BLK, BLK*2, EINVAL);
    check(NBD_CMD_WRITE, UINT64_MAX-BLK+1, BLK, EINVAL);
    check(NBD_CMD_WRITE, 1, BLK, EINVAL);
    check(NBD_CMD_READ, 0, 1, EINVAL);
    check(NBD_CMD_READ, 0, MX+BLK, E2BIG);
    check(NBD_CMD_WRITE | NBD_CMD_FLAG_FUA, 0, BLK, EOPNOTSUPP);
    check(NBD_CMD_FLUSH, 0, 0, 0);
    check(NBD_CMD_FLUSH, 0, BLK, EINVAL);
    check(NBD_CMD_DISC, 0, 0, 0);
    check(NBD_CMD_DISC, 0, BLK, EINVAL);
    check(NBD_CMD_TRIM, 0, BLK, EOPNOTSUPP);
    puts("PASS: 14 NBD validation cases");
}
