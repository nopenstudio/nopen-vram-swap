# Changelog

## v0.8.0 — SIGBUS diagnostics and direct-I/O validation (2026-10-25)

- Safety mode: 2048 MiB raw block only. Removed the v0.7 `--swap-experiment` pathway.
- Fatal signal diagnostics expanded with instruction pointer, stack pointer, last GPU segment and 4KiB block index (on x86_64).
- Save `/proc/self/maps` snapshot for instruction-pointer/module lookup.
- Signal handler re-raises the original fatal signal on its thread; a system coredump may be generated if enabled.
- OpenCL chunk latency instrumentation and slow transfer logging.
- Fail closed on post-GPU `mlockall()` failures.
- Require NBD device zero capacity before connecting.
- Random 4KiB O_DIRECT read/write test across the 2048 MiB range.
- Preserved NBD request validator and 14 unit tests.

**Not validated:** GPU runtime execution or swap workload with v0.8 on the user's RX 9060 XT.
**Known blocker:** v0.5 SIGBUS during actual swap; root cause unknown.
