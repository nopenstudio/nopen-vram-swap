#!/usr/bin/env python3
"""Destructive RAW NBD test only: random aligned O_DIRECT 4KiB I/O across 2GiB."""
import argparse
import mmap
import os
import random
import stat
import sys
import time

DEVICE = '/dev/nbd15'
SIZE = 2048 * 1024 * 1024
BLOCK = 4096

def preflight():
    st = os.stat(DEVICE)
    if not stat.S_ISBLK(st.st_mode):
        raise RuntimeError('nbd15 is not a block device')
    if not os.path.isfile('/sys/block/nbd15/pid'):
        raise RuntimeError('NBD15 not connected (missing sysfs pid)')
    with open('/sys/class/block/nbd15/size', encoding='ascii') as f:
        size = int(f.read()) * 512
    if size != SIZE:
        raise RuntimeError(f'Unexpected NBD capacity: {size}; expected {SIZE}')
    with open('/proc/swaps', encoding='utf-8') as f:
        if any(line.split() and line.split()[0] == DEVICE for line in f):
            raise RuntimeError('REFUSING destructive test on active SWAP')
    with open('/proc/self/mountinfo', encoding='utf-8') as f:
        dev_num = f'{os.major(st.st_rdev)}:{os.minor(st.st_rdev)}'
        if any(len(p := line.split()) > 2 and p[2] == dev_num for line in f):
            raise RuntimeError('REFUSING destructive test on mounted device')

def run(count):
    preflight()
    if not hasattr(os, 'O_DIRECT') or not hasattr(os, 'pwritev') or not hasattr(os, 'preadv'):
        raise RuntimeError('Requires Linux os.O_DIRECT, os.pwritev, os.preadv')
    fd = os.open(DEVICE, os.O_RDWR | os.O_DIRECT | os.O_CLOEXEC)
    write_buf = mmap.mmap(-1, BLOCK)
    read_buf = mmap.mmap(-1, BLOCK)
    rng = random.Random(0x4E4F50454E08)
    blocks = rng.sample(range(SIZE // BLOCK), count)
    start = time.monotonic()
    try:
        print(f'O_DIRECT 4KiB: {count} non-overlapping random blocks across 2048 MiB.')
        print('WARNING: THESE REGIONS ARE OVERWRITTEN. No SWAP may be active.')
        for i, k in enumerate(blocks):
            # Deterministic but unique, noncompressible-ish contents.
            local = random.Random((k << 15) ^ 0xC0FFEE08)
            write_buf[:] = local.randbytes(BLOCK)
            n = os.pwritev(fd, [write_buf], k * BLOCK)
            if n != BLOCK:
                raise OSError(f'Short write at block {k}: {n}')
            if (i + 1) % 1024 == 0:
                print(f'Written {i + 1}/{count}', flush=True)
        os.fsync(fd)
        print('Writes flushed. Reading in different order.', flush=True)
        rng.shuffle(blocks)
        for i, k in enumerate(blocks):
            n = os.preadv(fd, [read_buf], k * BLOCK)
            if n != BLOCK:
                raise OSError(f'Short read at block {k}: {n}')
            local = random.Random((k << 15) ^ 0xC0FFEE08)
            expected = local.randbytes(BLOCK)
            if read_buf[:] != expected:
                raise RuntimeError(f'DATA MISMATCH at block {k} (offset={k * BLOCK})')
            if (i + 1) % 1024 == 0:
                print(f'Verified {i + 1}/{count}', flush=True)
        seconds = time.monotonic() - start
        print(f'PASS: {count} independent 4KiB direct writes and reads; {seconds:.2f}s')
        print('RAW BLOCK PASS DOES NOT PROVE SWAP SAFETY OR GAME STABILITY.')
    finally:
        write_buf.close()
        read_buf.close()
        os.close(fd)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--count', type=int, default=4096, help='Unique 4KiB locations, 1..16384')
    args = parser.parse_args()
    if not 1 <= args.count <= 16384:
        parser.error('--count must be between 1 and 16384')
    try:
        run(args.count)
    except (OSError, RuntimeError) as exc:
        print(f'FAIL: {exc}', file=sys.stderr)
        sys.exit(1)
