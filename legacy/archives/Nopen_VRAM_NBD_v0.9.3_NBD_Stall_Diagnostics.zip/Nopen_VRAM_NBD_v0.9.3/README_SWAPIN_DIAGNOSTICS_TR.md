# v0.9.3 gerçek SWAP-IN tanısı

Önceki v0.9.2 izole döngü testinin ilk turu (1.536 MiB sayfa çıkışı, ~1.473 MiB NBD okuması, doğrulanan baytlar) başarılıydı. İkinci tur yalnız toplam SWAP kullanılan kapasite artışı 768 MiB'den az kaldığı için erken durdu. Aynı SWAP yuvasının yeniden kullanılması kullanılan kapasiteyi büyütmeyebilir.

v0.9.3 testinde her tur için **`pswpout` sayfa artışı, NBD yazılan sektör değişimi, anlamlı VRAM takas doluluğu** aranır. Geri okuma için `pswpin`, NBD okunan sektör artışı ve her sayfanın veri deseni doğrulanır. Gerçek aygıt okuması gözlenmezse `INCONCLUSIVE_SWAPIN` çıkar; bunlar bir uygulama tarafından otomatik başlatılmaz.

Deneysel ve riskli yürütme: `./run-isolated-cycle.sh`, RAM 768 MiB / swap 1800 MiB cgroup sınırında 1536 MiB veri ve iki tur. Bu sınır yalnız test sürecine uygulanır, bütün sistemi güvenli kılmaz. NBD kopmasında kalıcı veri kaybı ve SIGBUS mümkündür.
