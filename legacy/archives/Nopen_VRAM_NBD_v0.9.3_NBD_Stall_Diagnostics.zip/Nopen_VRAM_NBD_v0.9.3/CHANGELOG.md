# Changelog

## v0.9.3 — Socket backpressure diagnostics and reliability iteration
- Split NBD phase 16 into 161(reply header), 162(read payload), 163(socket send stalled), 164(socket receive stalled).
- Added live request handle/offset/length/opcode counters, bytes completed/expected, EAGAIN/poll counts and last progress/error timestamps. Logs are preserved at unexpected service exit.
- Use MSG_DONTWAIT for socket I/O with bounded 250ms poll retries; avoids opaque blocking send calls, does not impose an unsafe forced disconnect.
- Tune and log negotiated SO_SNDBUF/SO_RCVBUF, release extra userspace reference to kernel-side socket after NBD_SET_SOCK.
- Fix stale watchdog state after the NBD service exits; previous 61-second apparent send stall was ambiguous.
- Preserve limited VmLck/preload protections, service MemorySwapMax=0 and independent watchdog.
- Real page-cycle test validates physical NBD write sector delta rather than strict cumulative SWAP-used growth; v0.9.2 cycle-2 false negative corrected.
- Strengthen SWAP enable guard: require /dev/zram0 prio 100, refuse other active swap targets. Never touch NVMe swap.
- Add doctor-v093.sh and process wchan telemetry, fix coredumpctl diagnostic command.
- Host-only protocol test: 14 NBD request cases + 2MiB socket backpressure/error integrity + anonymous page self-test. No real GPU reliability claim.

## Known high-priority issue
- Kernel NBD can time out under memory pressure / GPU workload; losing swap pages then causes SIGBUS. **Not resolved in v0.9.3.**
