#ifndef NOPEN_NBD_IO_PROGRESS_H
#define NOPEN_NBD_IO_PROGRESS_H
/* Nopen v0.9.3: fully instrumented, allocation-free AF_UNIX NBD sender.
 * Unlike send(..., 0), MSG_DONTWAIT allows us to identify EAGAIN and partial
 * sends while waiting indefinitely (no arbitrary user-space disconnect).
 * The kernel's independent 60-second NBD timeout remains in force.
 * This function does not make swap over a user-space NBD daemon safe.
 */
#include <errno.h>
#include <poll.h>
#include <stdint.h>
#include <stdatomic.h>
#include <sys/socket.h>
#include <time.h>

struct nopen_tx_counters {
    _Atomic uint64_t *completed;
    _Atomic uint64_t *eagain;
    _Atomic uint64_t *polls;
    _Atomic uint64_t *last_error;
    _Atomic int *blocked_phase;
    _Atomic uint64_t *last_progress_ns;
};

static inline uint64_t nopen_tx_monotonic_ns(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC,&t)) return 0;
    return (uint64_t)t.tv_sec*1000000000ull+(uint64_t)t.tv_nsec;
}
static inline int nopen_send_progress(int fd, const void *data, size_t len,
                                      struct nopen_tx_counters *c) {
    const uint8_t *p = (const uint8_t *)data;
    while (len > 0) {
        ssize_t k = send(fd,p,len,MSG_NOSIGNAL|MSG_DONTWAIT);
        if (k > 0) {
            p += (size_t)k; len -= (size_t)k;
            atomic_fetch_add_explicit(c->completed,(uint64_t)k,memory_order_relaxed);
            atomic_store_explicit(c->last_progress_ns,nopen_tx_monotonic_ns(),memory_order_relaxed);
            continue;
        }
        if (k < 0 && errno == EINTR) continue;
        if (k < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == ENOBUFS)) {
            int oldphase=atomic_load_explicit(c->blocked_phase,memory_order_relaxed);
            atomic_store_explicit(c->blocked_phase,163,memory_order_relaxed);
            atomic_fetch_add_explicit(c->eagain,1,memory_order_relaxed);
            struct pollfd pfd={.fd=fd,.events=POLLOUT};
            int ready=poll(&pfd,1,250);
            atomic_fetch_add_explicit(c->polls,1,memory_order_relaxed);
            atomic_store_explicit(c->blocked_phase,oldphase,memory_order_relaxed);
            if (ready < 0 && errno == EINTR) continue;
            if (ready < 0) {
                atomic_store_explicit(c->last_error,(uint32_t)errno,memory_order_relaxed);
                return -1;
            }
            if (ready > 0 && (pfd.revents & (POLLERR|POLLHUP|POLLNVAL))) {
                errno = EPIPE;
                atomic_store_explicit(c->last_error,EPIPE,memory_order_relaxed);
                return -1;
            }
            continue;
        }
        if (k == 0) errno=EPIPE;
        atomic_store_explicit(c->last_error,(uint32_t)errno,memory_order_relaxed);
        return -1;
    }
    return 0;
}
#endif
