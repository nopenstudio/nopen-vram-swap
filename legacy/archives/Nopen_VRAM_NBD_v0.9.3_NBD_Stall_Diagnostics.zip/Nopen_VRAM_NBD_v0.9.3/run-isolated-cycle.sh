#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
if ! command -v systemd-run >/dev/null; then
  echo 'systemd-run missing; refusing non-isolated test' >&2; exit 1
fi
if [[ ! -e /sys/fs/cgroup/cgroup.controllers ]]; then
  echo 'cgroup v2 required; refusing non-isolated test' >&2; exit 1
fi
if ! grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
  echo 'VRAM SWAP NOT ACTIVE. Start service and activate via separate scripts.' >&2; exit 1
fi
if ! systemctl -q is-active nopen-vram-v093.service; then
  echo 'Nopen backend service not active; refusing' >&2; exit 1
fi
if ! systemctl --user show-environment >/dev/null 2>&1; then
  echo 'systemd user manager unavailable; refusing unisolated fallback' >&2; exit 1
fi
printf '%s\n'  'DANGER: 1536 MiB will be swapped via experimental NBD GPU backend.'  'Test process only: RAM cgroup max 768MiB; GPU backend runs OUTSIDE the test cgroup.'  'Nopen has previously frozen the machine under load. Save work.'
read -r -p 'Type EXACTLY IZOLASYONLU TEST to proceed: ' answer
[[ "$answer" == 'IZOLASYONLU TEST' ]] || { echo Cancelled; exit 1; }
exec systemd-run --user --scope --collect   --property=MemoryAccounting=yes   --property=MemoryMax=768M   --property=MemorySwapMax=1800M   /usr/bin/python3 -u "$(pwd)/test-real-swap-cycle.py"   --mib 1536 --cycles 2 --chunk-mib 64   --i-accept-crash-risk --require-isolated-memory
