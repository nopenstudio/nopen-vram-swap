#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
echo '=== NOPEN 0.9.3 READ-ONLY PRECHECK ==='
printf 'Kernel: '; uname -r
printf 'Desktop: %s\n' "${XDG_CURRENT_DESKTOP:-unknown}"
echo '=== Active swap ==='; swapon --show
if [[ -b /dev/nbd15 ]]; then
  echo '=== NBD15 ==='; lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS /dev/nbd15
  printf 'NBD15 kernel owner PID: '; cat /sys/block/nbd15/pid 2>/dev/null || echo none
fi
for unit in nopen-vram-v091 nopen-vram-v092 nopen-vram-v093; do
  printf '%s: ' "$unit"; systemctl is-active "$unit.service" 2>/dev/null || true
done
printf 'GPU DRM availability: '; ls /dev/dri/renderD* 2>/dev/null || true
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
  echo 'WARNING: NBD15 IS ACTIVE SWAP. Never disconnect the backend before swapoff.'
fi
if systemctl -q is-active nopen-vram-v091.service || systemctl -q is-active nopen-vram-v092.service; then
  echo 'REFUSE NEW START: older Nopen backend is still active.'
fi
echo 'Read-only report complete; nothing changed.'
