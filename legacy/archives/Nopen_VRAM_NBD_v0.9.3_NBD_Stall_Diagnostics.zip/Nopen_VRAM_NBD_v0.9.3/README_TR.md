# Nopen VRAM-NBD v0.9.3 — NBD soket kilitlenmesi inceleme sürümü

**DENEYSEL / GÜVENLİ DEĞİL.** v0.9.2 Bannerlord/Sway altında NBD bağlantısını kaybetti ve çok sayıda süreç SIGBUS ile çöktü. Bu paket **çöküşün tamamen düzeltildiğini iddia etmez**. 2 GiB VRAM, gerçek Linux RAM'i değil, `/dev/nbd15` üzerinden öncelikli bir takas aygıtıdır. SSD/NVMe üzerinde swap oluşturmaz.

## v0.9.2 kök-neden değerlendirmesi

22:50:19'da NBD kopması, 22:50:20'de toplu SIGBUS/SEGV ve 22:50:22'de Sway coredump gözlendi. 61.487 ms watchdog değeri doğrudan “61 saniye kesintisiz send()” kanıtı **değildir**: eski kod `serve()` çıkarken aktif istek saatini sıfırlamıyordu; bu yüzden watchdog eski isteği saymayı sürdürdü. `phase=16` de yanıt başlığı + okuma verisini tek aşamada topluyordu. GPU aktarımı ölçümünde 2,4 ms en kötü parça zamanı raporlandı; bu GPU sürücüsünün her türlü hatasını dışlamaz.

| Şüpheli | v0.9.3 müdahalesi | Kesin çözüldü mü? |
| --- | --- | --- |
| `send()` soket geri basıncı | `MSG_DONTWAIT`, 250 ms `poll()`, kısmi gönderim, `EAGAIN`, gerçek gönderilen bayt ve errno sayaçları; soket tamponu ölçümü | Hayır; tek isteğin sonsuz beklemesini önleme iddiası yok |
| `phase=16` belirsiz | 161=yanıt başlığı, 162=okuma verisi, 163=geri basınç, 164=alımda bekleme; istek kimliği/offset/uzunluk | Teşhis iyileşti |
| 61s sahte watchdog | `serve()` çıkışında aktif isteği temizle; varsa son anın sayaçlarını ayrıca kaydet | Evet, yanlış raporlama düzeltildi |
| Aşırı `VmLck` | v0.9.2'nin ikinci `mlockall()` çağrısını kaldıran düzeni ve 512 MiB üst sınır kontrolünü koru | 4,31 GiB sorununa yönelik; genel kararlılık garanti değil |
| GPU/OpenCL durması | Ayrı watchdog, GPU I/O evresi ve gecikmeleri ayrık ölç | Dışlanmadı |
| NBD çekirdek/reclaim deadlock | 60s kernel timeout **aynen korunur**, ani servis sonlandırma/otomatik restart yok, monitor ve kalıcı log | **Mimari risk sürüyor** |
| İkinci bellek döngüsü yanlış FAIL | Toplam takas kullanımının artması yerine `pswpout` + `/sys/block/nbd15/stat` fiziksel yazma deltasını kullan | Test ölçüm hatası giderildi |
| Çökme dosyası toplama | `coredumpctl --no-pager info` kullanımına geçildi, wchan izleme | Daha faydalı rapor |
| AMDGPU RA24 | İlk boot esnasında görülen RA24 uyarısı oyun anındaki kopmayla ilişkilendirilmedi | Ayrı, kanıtsız konu |

## Güvenli yükleme sırası

1. Eski v0.9.2 takasını, oyun kapalıyken **önce** `./disable-v092.sh` ile kapat. `swapoff` başarısızsa eski servisi kapatma, yeni sürüme geçme.
2. `swapon --show` yalnızca `/dev/zram0` göstermeli, `/dev/nbd15` `0B` olmalı.
3. ZIP'i bir klasöre çıkar ve kök klasöre gir. `make clean && make && make test` komutunu çalıştır.
4. `./doctor-v093.sh` salt-okunur ortam denetimidir; `sudo modprobe nbd nbds_max=16 max_part=0` gerekiyorsa modülü yükle.
5. `./start-v093.sh` yalnız GPU destekli **NBD aygıtını** açar; henüz swap açmaz.
6. İhtiyaç duyulursa `./enable-v093.sh` kritik onay ile `/dev/nbd15` üzerinde `mkswap`, `swapon -p 200` uygular. Sadece ZRAM 100 aktifken ve hiçbir NVMe swap yokken açılabilir.
7. `swapon --show`: `/dev/nbd15` 2G prio 200, `/dev/zram0` 7.3G prio 100 doğrulanmalı. Ciddi sistem çökmesi ihtimali devam eder. İlk yük testi, eğer risk kabul edildiyse, `./run-isolated-cycle.sh`.
8. Sonlandırma: oyun/test kapandıktan **sonra** `./disable-v093.sh`. `swapoff` başarıyla bitmeden servisi kapatma.

## Loglar ve çökme raporu

* `/var/log/nopen-vram-nbd-v093.log` — NBD istek evresi/soket ilerlemesi/error/EOF, watchdog, GPU olayları. O_DSYNC ile kalıcı yazmayı dener.
* `/var/log/nopen-vram-nbd-v093-telemetry.log` — swap/CPU/GPU/süreç ve iş parçacığı bekleme kanalı (wchan) snapshot'ları.
* `/var/log/nopen-vram-nbd-v093.maps` — adres haritası (gizli bilgiler barındırabilir).
* `test-runs/swap-cycle-*/events.jsonl` — gerçek sayfa takası testi aşamaları.
* Yeniden başlatma sonrası `./collect-after-reboot.sh`: `~/nopen-vram-experiment/nbd-beta-093/crash-report-*.tar.gz`.

**Önemli:** NBD çekirdeği bağlantıyı koparırsa ZRAM, VRAM'de *önceden kaybolmuş* takas sayfalarını kurtaramaz. Bu nedenle Bannerlord ile kullanım hâlâ test aşamasındadır. 60s zaman aşımı artırılarak bu sorunun çözüldüğü iddia edilmez. Gerçek AMD GPU burada bulunmadığından bu paket sadece derleme / birim testi doğrulaması aldı.
