#!/usr/bin/env bash
set -u
LOG=/var/log/nopen-vram-nbd-v093-telemetry.log
umask 077
exec >>"$LOG" 2>&1
echo "==== NOPEN093 MONITOR START $(date --iso-8601=seconds) BOOT=$(cat /proc/sys/kernel/random/boot_id) ===="
count=0; gone=0
while true; do
 echo "----- $(date --iso-8601=seconds) tick=$count -----"
 echo "state=$(systemctl is-active nopen-vram-v093.service 2>/dev/null || true)"
 cat /proc/pressure/memory 2>/dev/null || true
 grep -E "^(pswpin|pswpout) " /proc/vmstat 2>/dev/null || true
 [[ -r /sys/block/nbd15/stat ]] && echo "NBD15_STAT=$(cat /sys/block/nbd15/stat)"
 grep -E 'MemAvailable:|SwapTotal:|SwapFree:' /proc/meminfo || true
 swapon --show --bytes 2>/dev/null || true
 for c in /sys/class/drm/card*/device/mem_info_vram_used; do
  [[ -f "$c" ]] && echo "VRAM_USED:$c=$(cat "$c" 2>/dev/null)"
 done
 while read -r pid; do
   [[ -r /proc/$pid/status ]] || continue
   echo "PROC:$pid"
   grep -E 'VmRSS:|VmLck:|VmSwap:|State:' "/proc/$pid/status" 2>/dev/null || true
   # Independent kernel wait-channel snapshots: can expose blocked sendmsg/poll.
   for task in "/proc/$pid"/task/*; do
     [[ -d "$task" ]] || continue
     tid=${task##*/}
     echo "THREAD:$pid/$tid wchan=$(cat "$task/wchan" 2>/dev/null || true)"
   done
 done < <(pgrep -x nopen-vram-nbd || true)
 # Show where Nopen's main thread and workers slept during a slow NBD send.
 # /proc/.../wchan is a best-effort snapshot; it cannot prove a deadlock.
 if (( count % 3 == 0 )); then
  for pid in $(pgrep -x nopen-vram-nbd || true); do
   for task in /proc/"$pid"/task/*; do
    [[ -d "$task" ]] || continue
    tid=${task##*/}
    wchan=$(cat "$task/wchan" 2>/dev/null || echo unreadable)
    echo "THREAD pid=$pid tid=$tid wchan=$wchan"
   done
  done
  echo "SOCKSTAT_UNIX=$(cat /proc/net/sockstat 2>/dev/null | grep '^sockets:' || true)"
 fi
 count=$((count+1))
 if (( count % 5 == 0 )); then sync -f "$LOG" 2>/dev/null || sync; fi
 if systemctl -q is-active nopen-vram-v093.service; then gone=0; else gone=$((gone+1)); fi
 if (( gone >= 20 )); then
   echo 'BACKEND EXITED. LAST KERNEL EVENTS:'
   journalctl -k -b --since '-2 minutes' --no-pager 2>/dev/null | grep -Ei 'nbd15|amdgpu|oom|swap|bus error' | tail -n 80 || true
   sync -f "$LOG" 2>/dev/null || true
   break
 fi
 sleep 2
done
