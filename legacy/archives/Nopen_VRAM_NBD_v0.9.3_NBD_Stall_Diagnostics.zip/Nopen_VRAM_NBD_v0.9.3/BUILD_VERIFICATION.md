# Build / regression verification

Checked in this packaging environment:

- `make test`: **PASS**, 14 NBD request validation cases.
- 2 MiB real AF_UNIX socketpair with a deliberately slow receiving thread, 4096-byte send buffer: **PASS**, EAGAIN observed, POLLOUT wait observed, every byte verified. Deliberately disconnected peer correctly returns error.
- `python3 test-real-swap-cycle.py --self-test`: **PASS**, 8 MiB patterns + corruption detection + synthetic cycle-2 accounting regression. This self-test **does not enable SWAP**.
- `bash -n` on all `.sh`: **PASS**.
- `python -m py_compile` on all `.py`: **PASS**.
- `nopen-vram-nbd.c` built under GCC 12 with `-O2 -Wall -Wextra -Werror` and linked to installed OpenCL loader. The packaging environment lacks OpenCL SDK headers, so **temporary synthetic interface declarations** were used for compilation and were **not included in the ZIP**. On Garuda Linux use your real OpenCL headers/runtime with `make`.

Not checked: actual AMD GPU hardware, active `swapon`, Bannerlord focus pressure, kernel `NBD_SET_SOCK`, GPU memory allocation/residency, or true recurrent kernel NBD deadlock. No stability guarantee. The kernel has a 60-second timeout that can still drop the device and cause widespread SIGBUS. No automatic failover is possible for already-lost swap pages.

Notable provenance: v0.9.2 submitted previous-boot journal logs show `block nbd15: Send data failed (-11)` and `Receive data failed (-32)` at 2026-10-25 22:50:19, followed by device disconnect, `Read-error on swap-device`, and widespread SIGBUS. Backend watchdog reported last request phase=16. The first failing syscall could not be reconstructed retrospectively; this release adds detailed tracing to determine whether the userspace send path stalls or the kernel/socket receiver stops consuming data.
