#!/usr/bin/env bash
set -euo pipefail
ROOT="${HOME}/nopen-vram-experiment/nbd-beta-093"
mkdir -p "$ROOT"
DIR="$ROOT/crash-report-$(date +%Y%m%d-%H%M%S)"
mkdir -m 700 "$DIR"
for boot in -1 0; do
  tag=$([[ $boot == -1 ]] && echo previous || echo current)
  sudo journalctl -b "$boot" -u nopen-vram-v093.service --no-pager >"$DIR/$tag-nopen-unit.log" 2>&1 || true
  sudo journalctl -b "$boot" -u nopen-vram-v093-monitor.service --no-pager >"$DIR/$tag-monitor-unit.log" 2>&1 || true
  sudo journalctl -k -b "$boot" --no-pager | grep -Ei 'nbd15|swap|amdgpu|oom|bus error|hung task|blocked|killed process' >"$DIR/$tag-kernel.log" || true
  sudo journalctl -b "$boot" -o short-precise --no-pager | grep -Ei 'nopen-vram-nbd|SIGBUS|signal 7|systemd-coredump|out of memory' >"$DIR/$tag-coredump-events.log" || true
done
sudo coredumpctl --no-pager info nopen-vram-nbd >"$DIR/coredump-info.log" 2>&1 || true
for f in /var/log/nopen-vram-nbd-v093.log /var/log/nopen-vram-nbd-v093.maps /var/log/nopen-vram-nbd-v093-telemetry.log; do
  if sudo test -f "$f"; then sudo cp "$f" "$DIR/$(basename "$f")"; sudo chown "$(id -u):$(id -g)" "$DIR/$(basename "$f")"; fi
done
# Include recent anonymous-page swap cycling traces; no memory/core dump.
RUNS="$(dirname "$(readlink -f "$0")")/test-runs"
if [[ -d "$RUNS" ]]; then
  mkdir -p "$DIR/swap-cycle-tests"
  while IFS= read -r sub; do
    [[ -f "$sub/events.jsonl" ]] || continue
    cp "$sub/events.jsonl" "$DIR/swap-cycle-tests/$(basename "$sub").jsonl" || true
  done < <(find "$RUNS" -mindepth 1 -maxdepth 1 -type d -name 'swap-cycle-*' | sort -r | head -n 3)
fi
sudo journalctl --list-boots --no-pager >"$DIR/journal-boots.log" 2>&1 || true
# Summarize previous boot's GPU and NBD reset / timeout path independently.
sudo journalctl -k -b -1 --no-pager | grep -Ei 'block nbd15|nbd15:|I/O error|Read-error on swap-device|Write-error on swap-device|amdgpu.*(reset|timeout|fault)' >"$DIR/previous-critical-order.log" || true
# Latest Nopen flight-recorder entries are often more useful than coredumps.
swapon --show >"$DIR/current-swap.log"
free -h >"$DIR/current-free.log"
ARCHIVE="$ROOT/$(basename "$DIR").tar.gz"
tar -C "$ROOT" -czf "$ARCHIVE" "$(basename "$DIR")"
printf 'Saved diagnostic archive: %s\n' "$ARCHIVE"
echo 'Review logs for memory addresses and process metadata before making public.'
