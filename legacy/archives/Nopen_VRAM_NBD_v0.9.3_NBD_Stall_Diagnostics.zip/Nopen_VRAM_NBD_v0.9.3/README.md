# Nopen VRAM-NBD v0.9.3 (EXPERIMENTAL)

Linux swap-on-AMD-VRAM through userspace NBD + OpenCL. This is **not equivalent to physical RAM**. It has repeatedly caused whole-desktop SIGBUS cascades when the NBD connection died during Bannerlord workloads. Do not enable it for irreplaceable work.

This release separates NBD receive/write/GPU/read/reply-header/reply-payload/socket-backpressure phases, uses nonblocking socket I/O to observe partial sends and EAGAIN, keeps detailed request/errno counters and an independent watchdog, and corrects the prior stale-watchdog and cycle-2 swap-accounting false failures. It keeps the v0.9.2 RAM-lock restriction and the 60-second kernel NBD timeout (raising timeout is not a solution). No NVMe swap is created.

Quick commands in `README_TR.md`. Native build: `make clean && make && make test`. Before touching a real NBD device: `./doctor-v093.sh`. No automatically-enabled swap. The risk-acknowledged scripts are `start-v093.sh`, `enable-v093.sh`, `disable-v093.sh`; for isolated page swapping `run-isolated-cycle.sh`; diagnostics `collect-after-reboot.sh`.

**Tests run in creation environment**: NBD validator 14 cases, socket stress test with AF_UNIX backpressure and disconnected peer, Python memory pattern/cycle-accounting self-test, shell syntax and C compilation against temporary OpenCL API stubs. GPU hardware and Linux NBD live swap not available for verification here. Build and test with native OpenCL development headers/libraries on the target Garuda Linux host.

Upstream notes: userspace NBD swap with socket-backed workloads can encounter reclaim deadlocks. This package does not fix kernel reclaim paths or ensure uninterrupted GPU compute access.
