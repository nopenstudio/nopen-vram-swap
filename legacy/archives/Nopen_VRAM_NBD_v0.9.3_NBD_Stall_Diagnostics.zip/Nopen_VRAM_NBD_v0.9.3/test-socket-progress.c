#define _GNU_SOURCE
#include "nbd_io_progress.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define BYTES (2*1024*1024)
struct receiver { int fd; const unsigned char *original; int result; };
static void *slow_receiver(void *opaque) {
    struct receiver *r=opaque;
    unsigned char buf[8192];
    size_t pos=0;
    usleep(100000); /* force a small SO_SNDBUF to fill up */
    while (pos<BYTES) {
        ssize_t n=recv(r->fd,buf,sizeof buf,0);
        if (n<=0) {r->result=1;return NULL;}
        if (memcmp(buf,r->original+pos,(size_t)n)) {r->result=2;return NULL;}
        pos+=(size_t)n;
    }
    r->result=0;
    return NULL;
}
int main(void) {
    int fd[2];
    if (socketpair(AF_UNIX,SOCK_STREAM,0,fd)) {perror("socketpair");return 1;}
    int snd=4096;
    if (setsockopt(fd[0],SOL_SOCKET,SO_SNDBUF,&snd,sizeof snd)) return 2;
    unsigned char *payload=malloc(BYTES);
    if (!payload) return 3;
    for (size_t i=0;i<BYTES;i++) payload[i]=(unsigned char)(i*37u+11u);
    _Atomic uint64_t sent=0,eagain=0,polls=0,error=0,last_ns=0;
    _Atomic int phase=162;
    struct nopen_tx_counters cnt={&sent,&eagain,&polls,&error,&phase,&last_ns};
    struct receiver r={fd[1],payload,-1};
    pthread_t thread;
    if (pthread_create(&thread,NULL,slow_receiver,&r)) return 4;
    if (nopen_send_progress(fd[0],payload,BYTES,&cnt)) {perror("send");return 5;}
    pthread_join(thread,NULL);
    if (r.result || atomic_load(&sent)!=BYTES || !atomic_load(&eagain) || !atomic_load(&polls)) {
        fprintf(stderr,"FAIL socket progress result=%d sent=%llu eagain=%llu polls=%llu\n",r.result,
                (unsigned long long)atomic_load(&sent),(unsigned long long)atomic_load(&eagain),
                (unsigned long long)atomic_load(&polls));return 6;
    }
    close(fd[0]);close(fd[1]);
    if (socketpair(AF_UNIX,SOCK_STREAM,0,fd)) return 7;
    close(fd[1]);
    if (nopen_send_progress(fd[0],payload,4096,&cnt)==0 || !atomic_load(&error)) return 8;
    close(fd[0]);free(payload);
    printf("PASS: 2 MiB socket backpressure (partial send, EAGAIN, poll, exact bytes), disconnected peer. NO GPU SWAP USED.\n");
    return 0;
}
