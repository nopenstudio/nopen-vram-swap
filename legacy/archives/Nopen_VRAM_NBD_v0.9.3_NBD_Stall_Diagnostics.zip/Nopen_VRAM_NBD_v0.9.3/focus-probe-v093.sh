#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
# Differentiation experiment: Is Bannerlord focus enough to fail GPU OpenCL
# allocation even if NO active VRAM swap pages depend on /dev/nbd15?
# Does not do any block IO, does not modify swap, no sudo required.
if ! systemctl -q is-active nopen-vram-v093.service; then
  echo 'Start v0.9.3 backend first with ./start-v093.sh (do NOT enable swap).' >&2
  exit 1
fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
  echo 'REFUSED: VRAM-SWAP is active; this test needs GPU allocation without swap.' >&2
  exit 1
fi
if [[ $(cat /sys/block/nbd15/size 2>/dev/null || true) != 4194304 ]]; then
  echo 'REFUSED: /dev/nbd15 is not connected at 2 GiB.' >&2
  exit 1
fi
SECONDS_TO_WATCH=${1:-120}
if ! [[ "$SECONDS_TO_WATCH" =~ ^[0-9]+$ ]] || ((SECONDS_TO_WATCH<10 || SECONDS_TO_WATCH>600)); then
  echo 'Usage: ./focus-probe-v093.sh [10..600 seconds]' >&2
  exit 2
fi
mkdir -p test-runs
LOG="$(pwd)/test-runs/focus-no-swap-$(date +%Y%m%d-%H%M%S).log"
: >"$LOG"
printf 'v0.9.3 focus comparison, VRAM-SWAP OFF, duration=%ss; log=%s\n' "$SECONDS_TO_WATCH" "$LOG"
echo 'Switch to Bannerlord and back a few times. This only records state; NO NBD reads/writes are requested.'
for ((sec=0;sec<SECONDS_TO_WATCH;sec+=2)); do
  {
    echo "---- $(date --iso-8601=seconds) +${sec}s ----"
    echo "service=$(systemctl is-active nopen-vram-v093.service 2>/dev/null || true)"
    grep -E 'MemAvailable:|SwapTotal:|SwapFree:' /proc/meminfo || true
    cat /proc/pressure/memory 2>/dev/null || true
    echo 'swap:'; cat /proc/swaps
    echo "nbd_stat=$(cat /sys/block/nbd15/stat 2>/dev/null || true)"
    for f in /sys/class/drm/card*/device/mem_info_vram_used; do
      [[ -f "$f" ]] && echo "vram $f=$(cat "$f")"
    done
  } >>"$LOG" 2>&1
  if ! systemctl -q is-active nopen-vram-v093.service; then
    echo 'ERROR: Nopen service exited; review journal logs.' | tee -a "$LOG"
    exit 1
  fi
  sleep 2
done
printf 'Probe finished. Log: %s\n' "$LOG"
