# v0.9.1a — Takas geri okuma tanısı

Bu paket v0.9.1 kaynaklarının üzerine **yalnızca test betiği tanısı** ekler. NBD C sunucusu, başlatma/kapatma servisleri, sistemdeki swap öncelikleri değiştirilmedi. **SIGBUS veya sistem kilitlenmesi çözülmedi.**

Önceki çıktıda 1536 MiB /dev/nbd15 takasına yazıldı (`VmSwap=1536 MiB`, `pswpout=393216` sayfa), 1536 MiB bayt olarak doğru okundu; buna rağmen `pswpin=0` ve NBD takas kullanımının 1536 MiB'de kalması, sayfaların swap cache'den gelmiş olabileceğini düşündürüyor. Tek başına kanıt değil.

Yeni test `SwapCached`, test sürecinin `VmSwap`, major fault, NBD blok aygıtının fiziksel okuma sektörü ve `pswpin` sayaçlarını sayfa çıkarma öncesi ve sonrası kaydeder. `pagein_counters` sonucunu inceleyin. `INCONCLUSIVE_SWAPIN` çıktısı: veriler sağlam ama GPU'dan **fiziksel** geri okuma doğrulanmadı. Bu hata, veri bozulması demek değildir. Böyle bir durumda ek yük oluşturmadan durur; otomatik ikinci döngüye geçmez.

DİKKAT: Bu test yalnızca arızalı olduğu bilinen **deneysel** gerçek SWAP üzerinde çalışır ve yine tüm sistemi kilitleyebilir. Kaydedilmemiş işleriniz varken çalıştırmayın. NBD üzerinde aktif swap varsa sunucuyu Ctrl+C ile kapatmayın. `swapoff` başarıyla tamamlanmadan NBD'yi kapatmayın.

Kurulum: `make clean && make && make test`. Sistem swap durumunu `swapon --show` ile doğrulayın. Eski sistemd servisi aktifse, C çalıştırılabilirini üstüne yazmadan önce servisi güvenle durdurun; **aktif swap varken servisi durdurmayın**. Bu kaynak paket mevcut dizinden ayrı bir dizine kurulabilir. Test komutu:

`python3 -u ./test-real-swap-cycle.py --mib 1536 --cycles 2 --i-accept-crash-risk`

Log: `test-runs/swap-cycle-*/events.jsonl`.
