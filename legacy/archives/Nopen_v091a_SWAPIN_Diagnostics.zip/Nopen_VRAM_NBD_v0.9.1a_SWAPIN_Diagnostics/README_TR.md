# Nopen VRAM-NBD v0.9.1 — Gerçek Linux SWAP döngü testi

**UYARI:** Bu sürüm henüz güvenilir RAM/SWAP çözümü değildir. v0.5 ve v0.9 gerçek SWAP denemelerinde kilitlenmeler görüldü. v0.9.1'in GPU üzerinde test edildiğine veya eski hatanın çözüldüğüne dair elimizde doğrulama yok. Veri kaybı, sistem kilitlenmesi ve beklenmedik yeniden başlatma olasılığı vardır. Önemli dosyalarını kaydet; üretim ortamında çalıştırma.

Sürüm **v0.9.1**, **v1.0 değil**. GPU'da tam **2048 MiB** VRAM rezerve edilir; aktif olduğunda Linux takas öncelikleri **/dev/nbd15=200** ve **/dev/zram0=100** olur. NVMe SWAP **oluşturulmaz**.

## Daha önce ne test ettik?

- v0.8: 4096 rastgele **ham NBD blok** okuma/yazma testi geçti; bu Linux sayfa takası değildir.
- v0.9: Gerçek SWAP, yaklaşık 1,26 GiB NBD kullanımı gösterdi; ancak sistem dondu/yeniden başladı. Yeterli bilgi içeren son kernel günlükleri bulunamadı.
- **Henüz yapmadığımız:** Kullanıcı alanındaki anonim bellek sayfalarını kasıtlı biçimde VRAM-SWAP'e çıkarıp (`MADV_PAGEOUT`), yoğun biçimde geri çağırıp (**page-in**), *tam içerik karşılaştırması* yapıp aynı döngüyü tekrarlamak. Aşağıdaki yeni test bunun için yazıldı.

> Bu mekanizma GPU belleğini doğrudan CPU RAM'i yapmaz. Linux çekirdeği, bellek sayfalarını NBD blok aygıtına gönderir. `Mem: total` değeri 8 GB civarında kalır. `Swap:` kapasitesi artar.

## v0.9.1 kaynak değişiklikleri

- GPU tamponları oluşturulduktan sonra ikinci kez yapılan `mlockall(MCL_CURRENT)` kaldırıldı. v0.9'da **4,31 GiB VmLck** görülmüştü; kilitlenmenin kesin sebebi olduğu kanıtlanmış değil.
- Başlangıç `VmLck` kontrolü, CPU aktarım tamponu ve NBD/watchdog iş parçacıklarının kilitli yığınları eklendi.
- Ayrı NBD watchdog: **2 saniyeden uzun GPU işlemlerini** kalıcı olay günlüğüne geçiriyor. GPU sürücüsü veya çekirdek tamamen kitlenirse watchdog da çalışamayabilir.
- İki bağımsız systemd servisi: NBD backend ve düzenli `/var/log` telemetrisi.
- **YENİ** `test-real-swap-cycle.py`: Gerçek Linux anonim sayfa SWAP gidiş-dönüş testi.

## Kurulum

Eski v0.9 servisi varsa ve SWAP kapalıysa durdur. `/dev/nbd15` üzerindeki etkin SWAP'i servis çalışırken zorla koparma. Yeniden başlatmadan sonra normal şartlarda NBD aygıtı `0B` olmalı.

```bash
cd ~/nopen-vram-experiment/nbd-beta-091/Nopen_VRAM_NBD_v0.9.1
make clean && make && make test
sudo modprobe nbd nbds_max=16 max_part=0
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS /dev/nbd15
```

`make test` sadece C istek doğrulama ve 8 MiB Python desen sınamasıdır; **SWAP etkinleştirmez**.

### A. Nopen'ı başlat

```bash
./start-v091.sh
```

Bu komut sistemd servisini başlatır, ancak SWAP **henüz aktif değildir**. Hata olursa:

```bash
sudo journalctl -u nopen-vram-v091.service -n 80 --no-pager
```

### B. Gerçek VRAM SWAP'i etkinleştir (tehlikeli)

```bash
./enable-v091.sh
swapon --show
```

Onay metnini birebir yazmak gerekir: `EVET SIGBUS RISKI`.
Beklenen `/dev/nbd15` önceliği `200`, ZRAM önceliği `100`.

### C. Yeni gerçek takas döngüsü testi (oyunu açmadan önce)

**Bellek baskısı ve SWAP hatası sistemini düşürebilir.** Önemli dosyalarını kaydettikten sonra, kritik işler çalışmıyorken:

```bash
python3 -u ./test-real-swap-cycle.py --mib 1536 --cycles 2 --i-accept-crash-risk
```

Programın davranışı:

1. SWAP'in gerçekten açık olduğunu, `/dev/nbd15` boyutunu ve VRAM önceliğinin ZRAM'den yüksek olduğunu kontrol eder. İzin verilmemiş ekstra SWAP varsa çalışmaz.
2. Başlangıçta yeterli kullanılabilir RAM arar. 1536 MiB **normal anonim CPU belleği** ayırır (GPU'ya doğrudan yazmaz).
3. Her 64 MiB blokta **tüm 4096 bayt sayfaları doldurur** ve Linux'a `MADV_PAGEOUT` ile takasa çıkarma isteği gönderir.
4. `/proc/vmstat` içinde `pswpout` artışını ve özellikle `/dev/nbd15` SWAP kullanımındaki artışı doğrular. İkisi de yeterli değilse *başarılı* sayılmaz.
5. Sayfaları tersten geri okur; **her 4 KiB sayfanın tüm baytlarını** kontrol eder. `pswpin` artışını doğrular.
6. İkinci döngüde desenleri değiştirir; tekrar yazma, takasa gönderme ve geri okuma yapar. Toplam hedef her yönde en az 2 × 1536 MiB sayfa taşınmasıdır; kesin aktarım sayaçlardan ölçülür.
7. Her önemli aşamayı `test-runs/swap-cycle-.../events.jsonl` dosyasına `fsync` ile kaydeder.

**Test ayırdığı bellek 1536 MiB olsa da NBD GPU kapasitesi 2048 MiB olarak kalır.** Bu bir **CPU'dan VRAM-SWAP'e sayfa değiştirme** testidir; GPU'yu fiziksel RAM yapmaz.

Eğer `MADV_PAGEOUT` çekirdek tarafından reddedilirse betik hata verir. Bellek geri kazanımı yapılamazsa yanlış başarı bildirmez. Oyun açmadan önce ilk döngü sonuçlarını kontrol et.

### D. Oyun gözlemi (yalnızca C testi geçtiyse; yine riskli)

```bash
watch -n 2 'swapon --show; echo; free -h'
```

Arka plandaki servisin ve telemetri günlüğünün devam ettiğini izle:

```bash
sudo journalctl -fu nopen-vram-v091.service
```

### E. Kapatma

Oyunu kapat. Döngü testi tamamlanmış olsun. Ardından:

```bash
./disable-v091.sh
```

**SWAP hâlâ açıksa Nopen servisini öldürme; `swapoff` de takılabilir.** Donanım/çekirdek donmasında tüm verileri kurtaracağımızı iddia etmiyoruz.

### F. Çöküşten sonra

Yeniden giriş yaptığında:

```bash
cd ~/nopen-vram-experiment/nbd-beta-091/Nopen_VRAM_NBD_v0.9.1
./collect-after-reboot.sh
```

Rapor önceki systemd günlüğünü, GPU/NBD olaylarını, en fazla son üç testin `events.jsonl` dosyalarını ve Nopen telemetrisini paketler. Rapor işlem ayrıntıları ve bellek adresleri içerebilir; **özel kayıtları GitHub'a herkese açık yükleme**.

## Başarı kriteri

`TEST_PASS` ancak testin aktif öncelikli VRAM-SWAP'i doğrulaması, `pswpout` ve `/dev/nbd15 USED` değerlerinin artması, `pswpin` artması ve **bütün bellek sayfalarının birebir aynı dönmesi** halinde yazılır. Bu test geçse bile Bannerlord ve uzun süreli sistem kararlılığı **kanıtlanmış olmayacak**.
