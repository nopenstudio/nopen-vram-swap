# Changelog

## v0.9.1 — experimental memory-lock correction, watchdog, and real swap cycles

- Retained 2048 MiB GPU block capacity and opt-in swap priority 200 above ZRAM 100.
- Removed second post-OpenCL `mlockall(MCL_CURRENT)` and added 512 MiB VmLck guard; actual behavior on gfx1200 awaits verification.
- Locked NBD/watchdog stacks and CPU I/O buffer; watchdog records >=2s GPU operations without initiating a dangerous detach.
- Separate systemd backend and swap-safe monitoring with `pswpin`, `pswpout`, NBD device I/O and MemAvailable.
- **NEW** `test-real-swap-cycle.py`: 1536 MiB anonymous pageout/pagein integrity stress, two cycles, unique page signatures, Linux swap-counter confirmation, and persistent JSONL logs.
- `make test` now validates 14 NBD request cases **plus** 8 MiB page-pattern self-test (without activating swap).
- After-reboot report includes the three most recent stress-test event logs.
- **NOT VERIFIED:** real NBD swap reliability, fix for v0.9 freeze, performance under Bannerlord, restart recovery.

## v0.9.0-experimental

- Initial 2048 MiB NBD-backed SWAP canary with explicit risk opt-in.
- Systemd backend isolation and telemetry logging.
- First real-swap test reached about 1.26 GiB used VRAM swap, then host froze; root cause unconfirmed.
