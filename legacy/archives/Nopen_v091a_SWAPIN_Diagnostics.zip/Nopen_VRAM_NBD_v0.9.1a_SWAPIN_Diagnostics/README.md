# Nopen VRAM-NBD v0.9.1 — experimental real Linux swap page cycling

**Danger: not production-safe.** The previous 2 GiB swap test froze the host. The root cause remains unconfirmed. The Linux NBD userspace server and AMD OpenCL GPU driver can deadlock or crash under memory pressure and destroy swapped pages. Save important files; do not run on production systems.

The GPU-backed block device reserves **2048 MiB AMD VRAM**. The optional swap canary uses priority **200**, above `/dev/zram0` at priority **100**, with **no NVMe swap**.

## What changed since v0.9

- Avoid calling `mlockall(MCL_CURRENT)` a second time after allocating OpenCL GPU buffers, which coincided with an unexpectedly high 4.31 GiB `VmLck` value in v0.9 (causation unproven).
- Explicitly lock required CPU I/O buffers and NBD/watchdog thread stacks; reject an excessively high initial locked-memory value.
- Log GPU transfer stalls through an independent NBD watchdog and detached systemd telemetry monitor.
- Add `test-real-swap-cycle.py`, a real Linux **anonymous-page swap-out / swap-in / verify** test. Prior raw 4 KiB NBD I/O tests did not prove any swap behavior.

## Run

```bash
make clean && make && make test
sudo modprobe nbd nbds_max=16 max_part=0
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS /dev/nbd15
./start-v091.sh
./enable-v091.sh  # explicit EVET SIGBUS RISKI confirmation required
swapon --show
python3 -u ./test-real-swap-cycle.py --mib 1536 --cycles 2 --i-accept-crash-risk
# After the test AND after closing all active workloads:
./disable-v091.sh
```

`make test` only performs safe validation/self-tests. The experimental activation and memory cycle are **separate**, intentionally risky operations.

The cycle test writes distinct checked 4 KiB anonymous pages, calls Linux `MADV_PAGEOUT` in 64 MiB segments, checks `pswpout` **and specifically /dev/nbd15 used swap growth**, reads all bytes back, verifies `pswpin`, and repeats with new patterns. It persists phase records under `test-runs/swap-cycle-*/events.jsonl` for post-reboot investigation. It is **not** direct CPU access to GPU memory, nor a substitute for physical DDR5 RAM.

For setup, safety checks, diagnostics, and post-reboot commands, see [README_TR.md](README_TR.md).
