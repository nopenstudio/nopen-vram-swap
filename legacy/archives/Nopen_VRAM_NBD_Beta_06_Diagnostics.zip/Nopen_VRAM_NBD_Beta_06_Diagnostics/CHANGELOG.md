# Changelog

## v0.6.0-diagnostics (25 October 2026)
- Recorded v0.5 SIGBUS as primary observed failure, followed by NBD socket death and swap read/write faults.
- Added async-signal-safe fault diagnostics to a root-only log file.
- Disabled `--swap-experiment` while investigating crashes.
- Kept v0.5 block tests; no claim of corrected swap safety.
