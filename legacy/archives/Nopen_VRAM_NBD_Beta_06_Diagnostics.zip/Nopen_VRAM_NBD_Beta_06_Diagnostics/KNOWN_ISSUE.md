# Known issue: 25 October 2026 SIGBUS

Observed chronological order:
1. systemd-coredump reports nopen-vram-nbd process 153753 terminated with SIGBUS at 20:49:23.087735.
2. NBD send/receive socket failures at 20:49:23.105+; dead connection and failed writes/reads.
3. Swap page read/write I/O errors and invalid swap entries.
4. systemd-oomd later reports severe memory pressure, and kills NetworkManager cgroup.

The original journal does not identify the faulting instruction or exact reason for SIGBUS.
Do not conclude that NBD timeout preceded the signal or that changing the timeout is a fix.
Potential hypotheses: GPU/driver mapping failure under VRAM contention, failing mmapped backing, RAM/VRAM pressure, other runtime faults. Requires diagnostics and repro.

This build intentionally refuses swap mode.
