# Nopen VRAM-NBD v0.6 — SIGBUS Tanilama

**UYARI: BU SURUM GERCEK SWAP ICIN DEGILDIR.** 25 Ekim 2026 deneyinde `nopen-vram-nbd` SIGBUS (signal 7) ile cöktü; sonrasinda `/dev/nbd15` I/O ve bellek sayfasi hatalari olustu. NBD zaman asimi arizanin ilk nedeni olarak kanitlanmadi.

## Ne degisti?

- SIGBUS/SIGSEGV durumunda async-signal-safe `write` ile evre/opcode/sinyal kodu/hata adresi kaydi: `/var/log/nopen-vram-nbd-v06.log`.
- Bir istek islenirken son asama numarasi kaydedilir. OpenCL'nin ic is parcaciklarindan gelen faultlarda asama **yalnizca son gorulen islemdir**, hatali kod satiri degildir.
- `--swap-experiment` parametresi bilerek reddedilir. `mkswap`/`swapon` KULLANMAYIN.
- v0.5'in bolunmus OpenCL bellek ve NBD ham blok testleri korunur.

## Derle

```bash
cd ~/nopen-vram-experiment/nbd-beta-06/Nopen_VRAM_NBD_Beta_06_Diagnostics
make clean && make && make test
```

## Normal ham blok denemesi

Bosta /dev/nbd15 aygitini dogrulayin. Tek terminalde:

```bash
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 128
```

Baska terminalde:

```bash
sudo python3 test-nbd-stress.py
```

**NOT:** `test-nbd-stress.py` onceki surumde 8 GiB aygiti bekliyorsa 128 MiB ile uygun degildir. 8 GiB ham aygit testi icin `--mib 8192` gerekir ve GPU VRAM kullanimini artirir. Once 128 MiB basit `dd/cmp` testi kullanin.

```bash
head -c 1048576 /dev/urandom > /tmp/nopen-v06-test.bin
sudo dd if=/tmp/nopen-v06-test.bin of=/dev/nbd15 bs=1M count=1 conv=fsync status=none
sudo dd if=/dev/nbd15 bs=1M count=1 iflag=fullblock status=none | cmp - /tmp/nopen-v06-test.bin
```

SIGBUS olursa once `sudo cat /var/log/nopen-vram-nbd-v06.log` ve `sudo journalctl -k -b --since '5 minutes ago'` ciktilarini kontrol edin.

## Asama kodlari

- 1 platform/device initialization; 2 GPU buffer allocation/fill; 3 GPU clFinish init
- 9 service preparation; 10 polling; 11 NBD header read; 12 NBD write payload read
- 13 GPU write; 14 GPU read; 15 GPU flush; 16 sending NBD reply; 18 cleanup

**Bilinen sinir:** Bu surum SIGBUS'u giderdigini iddia etmez; sadece gercek bellek kaybi olmadan tekrarlanabilirse daha iyi tani koymak icin yapildi. 8 GiB GPU tahsisi oyun icin uygun olmayabilir.
