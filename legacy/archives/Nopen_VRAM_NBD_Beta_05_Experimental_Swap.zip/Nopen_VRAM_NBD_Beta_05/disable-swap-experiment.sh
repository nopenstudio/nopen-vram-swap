#!/usr/bin/env bash
set -euo pipefail
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
    echo 'VRAM-SWAP kapatiliyor. Kullanilan sayfalar RAM/ZRAM tarafina tasinir; bellek doluysa islem basarisiz olabilir.'
    sudo swapoff /dev/nbd15
fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
    echo 'HATA: VRAM-SWAP hala etkin, sunucuyu KAPATMA.' >&2
    exit 1
fi
swapon --show
echo 'VRAM-SWAP etkin degil. Simdi sunucu terminalinde Ctrl+C kullanabilirsin.'
