# Nopen VRAM-NBD v0.5.0-beta — Deneysel GPU-SWAP

Bu kod AMD OpenCL tamponlarından `/dev/nbd15` blok aygıtı sunar. Beta 0.4 deneyindeki 8 GiB yazma/okuma testi geçmiştir. **v0.5 gerçek GPU-SWAP üzerinde henüz çalıştırılmamıştır** ve bellek baskısı altında kilitlenebilir.

## Güvenlik

* NBD arka ucu kullanıcı alanında ve GPU sürücüsüne bağlıdır. RAM tamamen dolduğunda çıkmaz (deadlock), GPU sıfırlanmasında SWAP sayfalarının kaybı, oyun veya sistem çökmesi mümkündür.
* Programın Ctrl+C ile kapatılmasını aktif SWAP sırasında engelleyen kontrol **yalnızca kazara kapatmayı azaltır**; `SIGKILL`, GPU/sürücü çökmesi, OOM-killer veya kernel hataları için koruma sağlamaz.
* Bu yazılım gerçek kullanım için güvenli değildir. Deneme öncesi kaydedilmemiş işlerini kaydet, dosyalarını yedekle. Sway/masaüstü oturumunun çökebileceğini kabul et. ZRAM'i kapatma.
* `/dev/nbd15` aygıtını boş olduğunu görmeden kullanma. Asla `/dev/nvme...` yolunu bunun yerine yazma.

## Kurulum

```bash
sudo pacman -S --needed base-devel opencl-headers ocl-icd
make clean && make && make test
sudo modprobe nbd nbds_max=16 max_part=0
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
swapon --show
```

## İlk aşama: deneme sunucusu

Birinci terminal:

```bash
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 8192 --swap-experiment
```

İkinci terminalde doğrula:

```bash
sudo blockdev --getsize64 /dev/nbd15   # 8589934592 beklenir
swapon --show                           # ZRAM kullanılmaya devam etmeli
```

## İsteğe bağlı, tehlikeli gerçek SWAP denemesi

**Yalnızca bilerek kabul ediyorsan** aşağıdaki komutları çalıştır. `mkswap` aygıtın içeriğini siler.

```bash
sudo mkswap -f /dev/nbd15
sudo swapon -p 200 /dev/nbd15
swapon --show
```

Mevcut ZRAM önceliği 100 ise 200 > 100; Linux swap sayfalarını VRAM-SWAP'e öncelikli göndermeyi dener. Daha önce ZRAM'e yazılmış sayfalar otomatik taşınmaz. Bu sıralama performans garantisi **değildir**.

## Durdurma

**Sunucu terminalinde Ctrl+C ÖNCE YAPMA.** Oyun kapatıldıktan sonra ikinci terminalde:

```bash
sudo swapoff /dev/nbd15
swapon --show
```

Yalnızca `/dev/nbd15` artık `swapon --show` içinde görünmüyorsa sunucu terminalinde Ctrl+C ile çık. `swapoff` donarsa **sunucuyu öldürme**; bu durumda sistem verilerini kurtaramayabilir.

## Test

```bash
sudo python3 test-nbd-stress.py
```

Ham blok testi **aktif SWAP varken çalıştırma** (swap sayfalarını bozarsın). `test-nbd-8g.sh` de yalnızca SWAP etkin değilken.

## Teknik

* C/OpenCL; 256 MiB parçalara bölünmüş VRAM.
* NBD başlık doğrulaması, 16 MiB aktarma tamponu, `mlockall(MCL_CURRENT)` ve `mlock`.
* SIGINT/SIGTERM için etkin takası kontrol edip istemli kapatmayı reddetme.
* I/O istatistikleri.
* GPU/OpenCL ve Linux bellek geri kazanım yollarında gerçek zamanlı ilerleme garantisi yoktur.

### Kolay deneme betikleri

Yukarıdaki elle kullanılan `mkswap/swapon` komutları yerine, **`--swap-experiment` ile sunucu başlatıldıktan sonra** ikinci terminalde `./enable-swap-experiment.sh` komutu kullanılabilir. Etkinleştirmeden önce cihazı ve programın çalışma modunu kontrol edip açıkça `EVET` onayı ister. İşin bitince `./disable-swap-experiment.sh` çalıştırılır.
