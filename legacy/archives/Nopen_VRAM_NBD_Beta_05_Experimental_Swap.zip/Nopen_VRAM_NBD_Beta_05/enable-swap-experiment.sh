#!/usr/bin/env bash
# UNSAFE EXPERIMENT: NBD userspace GPU-backed swap may deadlock the OS.
set -euo pipefail
DEV=/dev/nbd15
EXPECTED=8589934592
if [[ ! -b "$DEV" ]]; then echo 'HATA: /dev/nbd15 blok aygiti bulunamadi.' >&2; exit 1; fi
if [[ ! -s /sys/block/nbd15/pid ]]; then echo 'HATA: /dev/nbd15 bagli NBD sunucusu yok.' >&2; exit 1; fi
size=$(sudo blockdev --getsize64 "$DEV")
if [[ "$size" != "$EXPECTED" ]]; then echo "HATA: $DEV boyut $size; 8589934592 bekleniyor." >&2; exit 1; fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then echo 'HATA: VRAM-SWAP zaten aktif.' >&2; exit 1; fi
if findmnt -rn --source "$DEV" | grep -q .; then echo 'HATA: Aygit mount edilmis.' >&2; exit 1; fi
if ! pgrep -x nopen-vram-nbd >/dev/null; then echo 'HATA: nopen-vram-nbd sunucusu calismiyor.' >&2; exit 1; fi
if ! tr '\0' ' ' </proc/$(pgrep -xo nopen-vram-nbd)/cmdline | grep -q -- '--swap-experiment'; then
    echo 'HATA: Nopen sunucusu --swap-experiment modunda baslatilmamis.' >&2; exit 1
fi
printf '%s\n' 'TEHLIKE: Linux/GPU kitlenebilir; veri kaybi olabilir. Kaydedilmemis isleri kaydet.' \
'8 GiB VRAM takasi oncelik 200 ile etkinlestirilecek. ZRAM mevcut onceligi ile korunacak.' \
'Yalnizca /dev/nbd15 uzerinde mkswap yapilir; tum mevcut blok verisi silinir.'
read -r -p "Devam etmek icin tam olarak EVET yaz: " answer
if [[ "$answer" != EVET ]]; then echo 'Iptal.'; exit 1; fi
sudo mkswap -f "$DEV"
sudo swapon --priority 200 "$DEV"
swapon --show
printf '\n%s\n' 'VRAM-SWAP deneysel olarak etkin. SUNUCUYU KAPATMA!' \
'Oyun bittikten sonra ./disable-swap-experiment.sh calistir.'
