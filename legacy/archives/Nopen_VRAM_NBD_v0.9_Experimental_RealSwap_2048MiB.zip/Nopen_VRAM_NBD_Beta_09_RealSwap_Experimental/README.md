# Nopen VRAM-NBD v0.9 — high-risk Linux swap canary

This experiment exposes exactly **2048 MiB of AMD GPU VRAM** through a Linux NBD block device and offers an opt-in **swap priority 200**, above the user's existing ZRAM priority 100. It creates **no NVMe swap**.

**Unresolved serious issue:** v0.5 crashed with `SIGBUS` under genuine memory pressure and caused NBD swap read/write failures; applications including Sway and Steam crashed. The 0.8 random direct I/O benchmark passed, but that does **not** establish swap safety. v0.9 adds a segregated systemd service, memory swap exclusion for the NBD service cgroup, and persistent telemetry. These measures are experimental, not a verified fix.

For a full Turkish guide, see [README_TR.md](README_TR.md).

## Contents
- `start-v09.sh`: launches isolated systemd backend (swap not active yet).
- `enable-v09.sh`: verifies correct process + device and explicitly opts in to `mkswap` and `swapon -p 200` on `/dev/nbd15` **only**.
- `monitor-v09.sh`: detached telemetry collector to `/var/log/nopen-vram-nbd-v09-telemetry.log`.
- `disable-v09.sh`: attempts `swapoff` first; stops backend only afterwards.
- `collect-after-reboot.sh`: bundle journal, kernel, and Nopen diagnostic logs (not full core dumps).

**Save all work before attempting real swap. Do not use on machines storing irreplaceable data.**
