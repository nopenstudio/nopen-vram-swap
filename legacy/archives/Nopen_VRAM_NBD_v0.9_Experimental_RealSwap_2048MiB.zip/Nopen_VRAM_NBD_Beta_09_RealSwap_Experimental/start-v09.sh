#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
DEV=/dev/nbd15
if [[ ! -x ./nopen-vram-nbd ]]; then echo 'Compile first: make clean && make && make test' >&2; exit 1; fi
if [[ ! -b "$DEV" ]]; then echo 'Missing /dev/nbd15: sudo modprobe nbd nbds_max=16 max_part=0' >&2; exit 1; fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then echo 'REFUSED: /dev/nbd15 already swap' >&2; exit 1; fi
if [[ $(cat /sys/block/nbd15/size) != 0 ]] || [[ -s /sys/block/nbd15/pid ]]; then echo 'REFUSED: /dev/nbd15 is already connected. Stop OLD raw-only server with Ctrl+C FIRST.' >&2; exit 1; fi
if systemctl -q is-active nopen-vram-v09.service; then echo 'v0.9 service already running' >&2; exit 1; fi
printf '%s\n' 'HIGH RISK: v0.5 SIGBUS killed the NBD daemon and invalidated SWAP pages.' 'v0.9 is experimental; crashes and unsaved-data loss remain possible.' 'The 2 GiB GPU reservation is NOT regular CPU RAM.'
sudo systemd-run --unit=nopen-vram-v09 --description='Nopen v0.9 experimental GPU swap backend' --collect \
    --property=Type=simple --property=Restart=no \
    --property=LimitMEMLOCK=infinity --property=LimitCORE=infinity \
    --property=MemorySwapMax=0 --property=OOMScoreAdjust=-800 \
    --property=StandardOutput=journal --property=StandardError=journal \
    "$(pwd)/nopen-vram-nbd" --device "$DEV" --mib 2048 --swap-experiment --accept-crash-risk
for i in {1..15}; do
    if [[ $(cat /sys/block/nbd15/size 2>/dev/null || echo 0) == 4194304 ]] && systemctl -q is-active nopen-vram-v09.service; then
        echo 'Backend READY, but swap is NOT active yet.'
        echo 'Use: ./enable-v09.sh'
        exit 0
    fi
    sleep 1
done
printf '%s\n' 'STARTUP FAILED OR TIMED OUT. See: sudo journalctl -u nopen-vram-v09 -n 70 --no-pager' >&2
exit 1
