# Changelog

## 0.9.0-experimental
- 2048 MiB explicit high-risk SWAP mode on top of v0.8 raw block backend.
- Separate transient systemd service so the GPU backend survives a Sway logout.
- Service memory swap cap (0), increased memlock and core limits (best effort).
- Persistent OpenCL/NBD event log with `O_DSYNC` and 5s heartbeat.
- Independent systemd monitoring service records VRAM, RSS, pressure, swap use and journal clues.
- Clear preflight and confirmation before mkswap on exclusively `/dev/nbd15`.
- Post-reboot report collection script, no raw core dumps bundled.
- **Known unresolved SIGBUS risk**; no reliability claims.
