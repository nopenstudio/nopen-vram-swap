# Nopen VRAM-NBD v0.9 — Gerçek SWAP deneyi (2048 MiB)

**TEHLİKELİ, DENEYSEL, HENÜZ GÜVENLİ DEĞİL.** Önceki v0.5 gerçek SWAP testi SIGBUS ve kernel takas hatalarıyla çöktü. v0.8 ham blok testinin geçmesi bu problemi çözmüyor. Bu sürümün amacı aynı deneyi *kalıcı* günlüklerle ve ayrı systemd servisiyle izlemek; çökmenin giderildiği iddia edilmiyor.

Hedef: /dev/nbd15 üzerinde **2048 MiB GPU-backed SWAP priority 200**; mevcut `/dev/zram0` öncelik 100, SSD swap yok.

## Nasıl çalışır?
- `start-v09.sh`: 2 GiB VRAM NBD sunucusunu systemd servisinde çalıştırır; servis kullanıcının Sway oturumundan bağımsızdır. `MemorySwapMax=0`, `LimitMEMLOCK=infinity`, `LimitCORE=infinity`, `OOMScoreAdjust=-800` kullanır. Bunların **hiçbiri** GPU sürücüsü ölümlerini ya da kernel deadlock'ları engelleyemez.
- `enable-v09.sh`: Çalışan doğru sunucu, NBD bağlantısı ve boyutunu doğrular; bağımsız kalıcı monitor servisini başlatır; açık **EVET SIGBUS RISKI** onayı ister; sadece `/dev/nbd15` üzerinde mkswap ve `swapon -p 200` yapar.
- `disable-v09.sh`: Başarabilirse swapoff ve sonra backend'i kapatır. Backend çökmüşse `swapoff` bloke olabilir.
- `collect-after-reboot.sh`: Önceki ve şu anki açılışın journal, kernel, coredump metaverisi, Nopen hata günlüğü ve GPU bellek telemetrisini paketler.

## İlk adımlar
1. **KAYDET / YEDEKLE.** Açık oyun ve kritik işlemleri başlatmadan önce dosyaları kaydet.
2. Eski v0.8 sunucusu `/dev/nbd15` üzerinde SWAP değilse kendi terminalinden Ctrl+C ile kapat; `lsblk` 0B olmalı.
3. `make clean && make && make test`.
4. `sudo modprobe nbd nbds_max=16 max_part=0`
5. `./start-v09.sh`
6. `./enable-v09.sh` (manuel onay gerekir)
7. `swapon --show` VRAM 200 / ZRAM 100 göstermelidir.
8. Bannerlord testi; oyun açıkken `sudo journalctl -fu nopen-vram-v09` ve `sudo tail -f /var/log/nopen-vram-nbd-v09-telemetry.log` ile takip edebilirsin.
9. Oyun kapatıldıktan sonra `./disable-v09.sh`; **SWAP aktifte backend'i öldürme**.
10. Yeniden başlatma sonrası `./collect-after-reboot.sh`.

## Coredump uyarısı
Crash dump RAM'in önemli parçalarını içerebilir; kamuya açık GitHub deposuna `core` dosyası YÜKLEME. `collect-after-reboot.sh` yalnızca `coredumpctl info` çıktısını paketler, belleği değil. Oturum kapanması, GPU kilitlenmesi ve dosya kaybı hâlâ mümkündür.

## Doğrulama kapsamı
`make test` yalnızca 14 NBD istek doğrulama testini çalıştırır. OpenCL derlemesi Garuda'da yapılır. v0.9 kullanıcı GPU'sunda henüz denenmedi.
