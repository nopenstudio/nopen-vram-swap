#!/usr/bin/env python3
"""Nopen 8-GiB VRAM NBD non-swap stress test. Destroys selected /dev/nbd15 data."""
import hashlib
import mmap
import os
import random
import subprocess
import sys

DEVICE = "/dev/nbd15"  # hard-coded to avoid accidental disk targeting
SIZE = 8192 * 1024 * 1024
MIB = 1024 * 1024
LENGTH = 4 * MIB
COUNT = 64


def fail(message):
    raise SystemExit("HATA: " + message)


def check_device():
    if os.geteuid() != 0:
        fail("sudo ile çalıştır: sudo python3 test-nbd-stress.py")
    if not os.path.exists(DEVICE) or not os.path.exists("/sys/block/nbd15/pid"):
        fail("nbd15 bulunamadı / bağlı değil")
    pid = open("/sys/block/nbd15/pid", encoding="ascii").read().strip()
    if not pid.isdigit():
        fail("nbd15 için aktif NBD PID bulunamadı")
    bytes_size = int(open("/sys/block/nbd15/size", encoding="ascii").read()) * 512
    if bytes_size != SIZE:
        fail(f"nbd15 tam 8 GiB değil: {bytes_size} bayt")
    swaps = open("/proc/swaps", encoding="utf-8").read()
    if any(line.split() and line.split()[0].startswith(DEVICE) for line in swaps.splitlines()[1:]):
        fail("nbd15 veya bölümü SWAP olarak etkin, test reddedildi")
    proc = subprocess.run(["findmnt", "-rn", "--source", DEVICE], capture_output=True, text=True)
    if proc.stdout.strip():
        fail("nbd15 bağlanmış bir dosya sistemi, test reddedildi")
    running = subprocess.run(["pgrep", "-x", "nopen-vram-nbd"], capture_output=True)
    if running.returncode:
        fail("Nopen VRAM-NBD programı bulunamadı")
    return pid


def positions():
    chosen = [0, 255, 511, 1023, 2047, 4095, 6143, 8188]
    rng = random.Random(0x9060)
    while len(chosen) < COUNT:
        candidate = rng.randrange(1, 8188)
        if all(abs(candidate - old) >= 4 for old in chosen):
            chosen.append(candidate)
    return chosen


def pattern(megabyte):
    # 4 MiB deterministic, distinct bytes per block, easy to reproduce.
    return hashlib.shake_256(f"nopen-vram-v04:{megabyte}".encode()).digest(LENGTH)


def main():
    pid = check_device()
    print(f"NBD connected (kernel PID {pid}), 8 GiB; no active SWAP. WARNING: destroys selected data on {DEVICE}.", flush=True)
    print(f"Testing {COUNT} independent 4 MiB regions = {COUNT*4} MiB, including cross-segment boundaries.", flush=True)
    offsets = positions()
    fd = os.open(DEVICE, os.O_RDWR | os.O_DIRECT | os.O_SYNC)
    buffer = mmap.mmap(-1, LENGTH)
    view = memoryview(buffer)
    checksums = {}
    try:
        for idx, off in enumerate(offsets, 1):
            view[:] = pattern(off)
            checksum = hashlib.sha256(view).digest()
            wrote = os.pwritev(fd, [view], off * MIB)
            if wrote != LENGTH:
                fail(f"Eksik yazma: offset {off} MiB; {wrote} bayt")
            checksums[off] = checksum
            if idx % 16 == 0:
                print(f"Written {idx}/{COUNT} regions", flush=True)
        os.fsync(fd)
        # Verify AFTER all writes: catches address aliasing across segments.
        for idx, off in enumerate(reversed(offsets), 1):
            read = os.preadv(fd, [view], off * MIB)
            if read != LENGTH or hashlib.sha256(view).digest() != checksums[off]:
                fail(f"VERI BUTUNLUGU HATASI! offset {off} MiB")
            if idx % 16 == 0:
                print(f"Verified {idx}/{COUNT} regions", flush=True)
        print("BASARILI: 256 MiB daginik NBD yazma ve sonradan okuma dogrulandi.", flush=True)
        print("NOT: SWAP/bellek baskisi, hiz veya tum 8 GiB'yi test ETMEZ.")
    finally:
        view.release()
        buffer.close()
        os.close(fd)


if __name__ == "__main__":
    main()
