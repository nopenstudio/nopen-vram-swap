# Nopen VRAM-NBD Beta 0.4 — Bellek kilitleme + bağımsız blok stres testi

Beta 0.3 üzerinde küçük güvenlik iyileştirmeleri ve ek 8 GiB blok testi.

## Yapılan değişiklikler
- Başlangıçta `mlockall(MCL_CURRENT)` ile **mevcut** kullanıcı alanı sayfalarını kilitlemeye çalışır. Gelecekte ayrılan GPU sürücüsü sayfalarını garanti etmez.
- 16 MiB aktarım tamponunu hizalar, `mlock` ile kilitler ve önceden dokunarak sayfalarını hazırlar.
- Yeni test, 64 farklı 4 MiB konuma (256 MiB örnek) yazar ve tüm yazmalar bittiğinde tersten yeniden okuyup SHA-256 karşılaştırır.
- `/dev/nbd15` sabitlenmiştir; 8 GiB boyut, NBD bağlılığı, aktif SWAP ve mount yokluğu kontrol edilir. Test yalnızca bu NBD aygıtındaki örnek bölgelerin verisini bozar.

## UYARI
**BU SÜRÜM HALA SWAP İÇİN GÜVENLİ DEĞİLDİR.** `mkswap`, `swapon`, `mkfs` çalıştırmayın. OpenCL/AMDGPU sürücüsü bellek baskısı altında yeni sayfa ayırabilir. GPU reseti veya sunucu hatası NBD'deki bütün veriyi kaybettirir. Masaüstü ve sistem kilitlenebilir.

## Kurulum

```bash
cd ~/nopen-vram-experiment/nbd-beta-04/Nopen_VRAM_NBD_Beta_04
make clean && make
```

Birinci terminal (`/dev/nbd15` boş, `0B` iken):

```bash
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 8192
```

İkinci terminal:

```bash
sudo python3 test-nbd-stress.py
```

Test sonunda aygıt üzerinde SWAP yokken ilk terminalde Ctrl+C, ardından `lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS` ve GPU VRAM kullanımını kontrol et.

### Amaç
Sonraki denemelerde performans ve bellek baskısını ayrıca sınamadan SWAP açılmayacak. Mevcut ZRAM'i kapatma.
