#!/usr/bin/env bash
set -euo pipefail
DEV=/dev/nbd15
SRC=$(mktemp /tmp/nopen-vram-b03.XXXXXXXX)
cleanup() { rm -f "$SRC"; }
trap cleanup EXIT

if [[ ! -b "$DEV" ]]; then echo "HATA: nbd15 blok aygiti yok." >&2; exit 1; fi
if [[ ! -s /sys/block/nbd15/pid ]]; then echo "HATA: nbd15 aktif bir NBD sunucusuna bagli degil." >&2; exit 1; fi
SIZE=$(sudo blockdev --getsize64 "$DEV")
if [[ "$SIZE" != '8589934592' ]]; then echo "HATA: $DEV 8 GiB degil ($SIZE byte); yazmayi reddediyorum." >&2; exit 1; fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then echo "HATA: nbd15 SWAP olarak kullanimda!" >&2; exit 1; fi
if findmnt -rn --source "$DEV" | grep -q .; then echo "HATA: nbd15 baglanmis!" >&2; exit 1; fi
if ! pgrep -x nopen-vram-nbd >/dev/null; then echo "HATA: Sunucu programi calismiyor." >&2; exit 1; fi

head -c 2097152 /dev/urandom > "$SRC"
for OFFSET in 0 255 4095 8190; do
    echo "Sinaniyor: offset ${OFFSET} MiB (2 MiB yaz, dogrudan geri oku)"
    sudo dd if="$SRC" of="$DEV" bs=1M seek="$OFFSET" count=2 oflag=direct conv=notrunc,fsync status=none
    sudo dd if="$DEV" bs=1M skip="$OFFSET" count=2 iflag=direct status=none | cmp - "$SRC"
done
echo "BASARILI: 8 GiB NBD'nin baslangic, 256 MiB, 4 GiB ve son sinirlari dogrulandi."
echo "NOT: Bu bir ham blok testi; SWAP kullanimi veya yuk altinda stabiliteyi kanitlamaz."
