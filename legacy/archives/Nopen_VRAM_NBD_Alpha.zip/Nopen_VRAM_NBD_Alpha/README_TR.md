# Nopen VRAM NBD Alpha (lab-only)

## Durum

Kod deneyseldir. AMD RX 9060 XT üzerinde henüz çalıştırılıp doğrulanmadı. **Gerçek Linux SWAP için güvenli değildir; kesinlikle swapon, mkswap, mkfs çalıştırmayın.** Bu ilk sürüm yalnızca boş NBD blok aygıtında veri yazma ve karşılaştırma içindir. Tüm veriler kapanışta kaybolur. GPU reset / sürücü hatası / OS kilitlenmesi / veri kaybı mümkündür.

Altyapı: Linux NBD ioctl socketpair, kullanıcı alanı C, OpenCL 1.2 GPU buffer. Tek seri I/O sunucusu; FUSE yok, veri doğrudan OpenCL belleğine yazılır. Linux kernelin PCIe/GPU sürücüsü RAM ihtiyacına bağımlılığı hâlâ vardır. Başlatılan programı SWAP olarak kullanmak henüz yasaktır.

## Önceki VRAMFS testini doğru biçimde tekrarlama

Son `cmp` başarılıydı ama `fusermount3 -u` sonrasında yapılmış olduğundan VRAM üzerinde değil `/tmp` üzerinde gerçekleşmiş olabilir. Bu nedenle doğrulama betiği **FUSE gerçekten bağlı değilse çalışmayı reddeder**.

1. terminal: `~/nopen-vram-experiment/vramfs/bin/vramfs /tmp/nopen-vram 2GB -f`

2. terminal: `./verify-vramfs.sh`

Sonra `fusermount3 -u /tmp/nopen-vram` ile kaldır. Bu doğrulama sonucu olumluysa NBD laboratuvarına geç.

## Kurulum (Garuda/Arch)

```bash
sudo pacman -S --needed base-devel opencl-headers ocl-icd
cd ~/Downloads/Nopen_VRAM_NBD_Alpha
make
```

Kodun sisteminizdeki OpenCL uyumluluğunu önce `clinfo -l` ile doğrulayın. Derleme başarıya ulaşsa bile NBD yolunun çalışacağı garanti edilmez.

## Çalıştırma (önerilen test: 128 MiB)

Tüm aktif uygulamaları ve önemli dosyaları kaydedin. Mevcut zram0 alanına DOKUNMAYIN. Tercihen test için başka oturum veya ayrı TTY hazır edin.

```bash
sudo modprobe nbd nbds_max=16 max_part=0
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
swapon --show
```

**/dev/nbd15 adlı aygıtın var, BOŞ ve kullanılmıyor olduğunu kendiniz doğrulayın.** Başka numara gerekiyorsa aşağıdaki tüm komutlarda aynı boş numarayı kullanın. Kullanımda olan hiçbir diski veya NBD cihazını asla seçmeyin.

1. terminal:

```bash
cd ~/Downloads/Nopen_VRAM_NBD_Alpha
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 128
```

2. terminal (yalnızca 1. terminal `READY` bildirirse):

```bash
sudo blockdev --getsize64 /dev/nbd15
head -c 16777216 /dev/urandom > /tmp/nopen-nbd-source.bin
sudo dd if=/tmp/nopen-nbd-source.bin of=/dev/nbd15 bs=1M count=16 status=progress conv=fsync
sudo dd if=/dev/nbd15 bs=1M count=16 iflag=fullblock status=none | cmp - /tmp/nopen-nbd-source.bin && echo 'NBD VRAM 16 MiB DOĞRULANDI'
rm -f /tmp/nopen-nbd-source.bin
```

`cmp` başarısızsa veya kernel NBD komutları hata veriyorsa bu sürümü SWAP için kullanmaya ÇALIŞMAYIN. Sorun çıkarsa `dmesg | tail -n 40` ve program çıktısını kaydedin.

Temiz kapanış: 1. terminalde **CTRL+C**. Ardından:

```bash
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
swapon --show
```

`/dev/nbd15` kullanımdaysa ve kapatmanız gerekiyorsa sadece bu deneme aygıtı için `sudo nbd-client -d /dev/nbd15` komutu kullanılabilir; bunun için Arch `nbd` paketi gerekir. Aktif swap verisi varsa önce güvenli swapoff olmadan bağlantıyı koparmayın (bu deneyde swap etkinleştirmeyin).

## Bilinen sınırlar

- Tek parça OpenCL buffer ayırıyor: `CL_DEVICE_MAX_MEM_ALLOC_SIZE` sınırı nedeniyle 8 GB mümkün olmayabilir; daha sonra çoklu tampon kullanımı gerekebilir.
- İşlemler senkron ve seri; performans daha sonra ölçülecek.
- GPU reset veya sürücü arızasında veri kaybolabilir; dosya sistemi kurmayın.
- Root altında ROCm/OpenCL aygıtı tanınmazsa bir sonraki sürümde GPU servisini kullanıcı yetkisiyle, NBD bağlayıcısını root olarak ayırmamız gerekir.
- I/O hataları için üretim düzeyinde geri kazanım, bellek kilitleme ve watchdog yok.
- Linux sistem belleğinin NBD GPU belleğine takaslanması döngüsel kilitlenme oluşturabilir; SWAP kesinlikle açılmamalı.
