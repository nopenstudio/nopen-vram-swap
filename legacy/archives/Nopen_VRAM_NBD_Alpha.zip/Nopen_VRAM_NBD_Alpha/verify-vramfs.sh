#!/usr/bin/env bash
set -euo pipefail
mp=/tmp/nopen-vram
fstype=$(findmnt -rn -o FSTYPE --mountpoint "$mp" || true)
if [[ "$fstype" != "fuse.vramfs" ]]; then
    echo "STOP: $mp is NOT a mounted fuse.vramfs filesystem (detected: ${fstype:-none})." >&2
    echo "Start vramfs in another terminal before running this test." >&2
    exit 2
fi
sourcefile=$(mktemp /tmp/nopen-src.XXXXXXXX)
vramfile=$(mktemp "$mp/nopen-test.XXXXXXXX")
trap 'rm -f -- "$sourcefile" "$vramfile"' EXIT
head -c 67108864 /dev/urandom > "$sourcefile"
cp -- "$sourcefile" "$vramfile"
if cmp -s -- "$sourcefile" "$vramfile"; then
    echo 'VRAMFS TEST PASSED: 64 MiB is bit-identical on mounted fuse.vramfs.'
else
    echo 'VRAMFS TEST FAILED: 64 MiB differs, or could not be read.' >&2
    exit 1
fi
