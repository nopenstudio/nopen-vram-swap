#!/usr/bin/env bash
set -euo pipefail
DEV=/dev/nbd15
FILE=/tmp/nopen-nbd-source.bin
cleanup() { rm -f "$FILE"; }
trap cleanup EXIT

if [[ ! -b "$DEV" ]]; then echo "HATA: $DEV blok aygiti yok" >&2; exit 1; fi
if [[ ! -s /sys/block/nbd15/pid ]]; then echo "HATA: $DEV bagli degil (NBD sunucusu gerekli)" >&2; exit 1; fi
if [[ $(sudo blockdev --getsize64 "$DEV") != 134217728 ]]; then
    echo "HATA: $DEV boyutu 128 MiB degil; yanlis aygita yazmayalim" >&2; exit 1
fi
if grep -Eq '^/dev/nbd15[[:space:]]' /proc/swaps; then
    echo "HATA: $DEV aktif swap, testi reddediyorum" >&2; exit 1
fi
if findmnt -rn --source "$DEV" | grep -q .; then
    echo "HATA: $DEV mount edilmis, testi reddediyorum" >&2; exit 1
fi
if ! pgrep -x nopen-vram-nbd >/dev/null; then
    echo "HATA: nopen-vram-nbd calismiyor" >&2; exit 1
fi

echo '16 MiB referans verisi uretiliyor...'
head -c 16777216 /dev/urandom > "$FILE"
echo 'VRAM destekli NBD aygitina 16 MiB yaziliyor...'
sudo dd if="$FILE" of="$DEV" bs=1M count=16 conv=fsync status=progress

echo '16 MiB blok verisi okunuyor ve karsilastiriliyor...'
sudo dd if="$DEV" bs=1M count=16 iflag=fullblock status=none | cmp - "$FILE"
echo 'BASARILI: 16 MiB NBD uzerinde bit-bit ayni!'
