#define _GNU_SOURCE
#define CL_TARGET_OPENCL_VERSION 120
#include <CL/cl.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <linux/nbd.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

/* Nopen VRAM-NBD beta 0.2: temporary raw block-device proof-of-concept.
 * NOT SAFE FOR SWAP OR PERSISTENT DATA. Run ONLY on a verified free /dev/nbdN.
 */
#define BLKSIZE 4096u
/* Kernel can merge multiple 1 MiB dd writes into a single 4 MiB NBD request. */
#define MAX_IO (16u*1024u*1024u)
#define MAGIC_REQ 0x25609513u
#define MAGIC_REP 0x67446698u

static volatile sig_atomic_t interrupted = 0;
static void stop_signal(int signal_number) { (void)signal_number; interrupted = 1; }

static uint64_t be64(uint64_t value) {
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    return ((uint64_t)htonl((uint32_t)(value & 0xffffffff)) << 32) |
           (uint64_t)htonl((uint32_t)(value >> 32));
#else
    return value;
#endif
}

static int recv_all(int fd, void *buf, size_t n) {
    uint8_t *p = (uint8_t *)buf;
    while (n) {
        ssize_t k = recv(fd, p, n, 0);
        if (k == 0) return -1;
        if (k < 0) { if (errno == EINTR && !interrupted) continue; return -1; }
        p += (size_t)k; n -= (size_t)k;
    }
    return 0;
}
static int send_all(int fd, const void *buf, size_t n) {
    const uint8_t *p = (const uint8_t *)buf;
    while (n) {
        ssize_t k = send(fd, p, n, MSG_NOSIGNAL);
        if (k <= 0) { if (k < 0 && errno == EINTR && !interrupted) continue; return -1; }
        p += (size_t)k; n -= (size_t)k;
    }
    return 0;
}

/* NBD WRITE carries request data BEFORE the reply. On rejection we must
 * consume it to keep the socket framing aligned for later requests. */
static int drain_write_payload(int fd, void *scratch, uint32_t length) {
    while (length) {
        size_t n = length < MAX_IO ? (size_t)length : MAX_IO;
        if (recv_all(fd, scratch, n)) return -1;
        length -= (uint32_t)n;
    }
    return 0;
}

struct gpu {
    cl_context context;
    cl_command_queue queue;
    cl_mem buffer;
    uint64_t bytes;
};

static void gpu_destroy(struct gpu *g) {
    if (g->queue) clFinish(g->queue);
    if (g->buffer) clReleaseMemObject(g->buffer);
    if (g->queue) clReleaseCommandQueue(g->queue);
    if (g->context) clReleaseContext(g->context);
    memset(g, 0, sizeof *g);
}

static int gpu_init(struct gpu *g, uint64_t size) {
    cl_uint np = 0;
    cl_int e = clGetPlatformIDs(0, NULL, &np);
    if (e != CL_SUCCESS || np == 0) { fprintf(stderr, "OpenCL platform unavailable: %d\n", e); return -1; }
    cl_platform_id *platforms = calloc(np, sizeof *platforms);
    if (!platforms) return -1;
    e = clGetPlatformIDs(np, platforms, NULL);
    cl_device_id device = NULL;
    for (cl_uint i = 0; e == CL_SUCCESS && i < np; ++i) {
        char vendor[256] = {0};
        clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof vendor, vendor, NULL);
        if (!strstr(vendor, "AMD") && !strstr(vendor, "Advanced Micro Devices")) continue;
        if (clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_GPU, 1, &device, NULL) == CL_SUCCESS) break;
        device = NULL;
    }
    free(platforms);
    if (!device) { fprintf(stderr, "No AMD OpenCL GPU found.\n"); return -1; }
    char name[256] = {0};
    clGetDeviceInfo(device, CL_DEVICE_NAME, sizeof name, name, NULL);
    cl_ulong allocmax = 0;
    clGetDeviceInfo(device, CL_DEVICE_MAX_MEM_ALLOC_SIZE, sizeof allocmax, &allocmax, NULL);
    if (size > allocmax) {
        fprintf(stderr, "Requested size exceeds CL_DEVICE_MAX_MEM_ALLOC_SIZE (%" PRIu64 " bytes).\n", (uint64_t)allocmax);
        return -1;
    }
    g->context = clCreateContext(NULL, 1, &device, NULL, NULL, &e);
    if (!g->context || e != CL_SUCCESS) { fprintf(stderr, "clCreateContext: %d\n", e); goto fail; }
    g->queue = clCreateCommandQueue(g->context, device, 0, &e);
    if (!g->queue || e != CL_SUCCESS) { fprintf(stderr, "clCreateCommandQueue: %d\n", e); goto fail; }
    g->buffer = clCreateBuffer(g->context, CL_MEM_READ_WRITE, (size_t)size, NULL, &e);
    if (!g->buffer || e != CL_SUCCESS) { fprintf(stderr, "clCreateBuffer: %d\n", e); goto fail; }
    uint32_t zero = 0;
    e = clEnqueueFillBuffer(g->queue, g->buffer, &zero, sizeof zero, 0, (size_t)size, 0, NULL, NULL);
    if (e == CL_SUCCESS) e = clFinish(g->queue);
    if (e != CL_SUCCESS) { fprintf(stderr, "GPU memory initialization failed: %d\n", e); goto fail; }
    g->bytes = size;
    fprintf(stderr, "GPU initialized: %s; allocated %" PRIu64 " MiB.\n", name, size / (1024 * 1024));
    return 0;
fail:
    gpu_destroy(g); return -1;
}

struct nbd_thread_args { int fd; int status; };
static void *nbd_thread(void *v) {
    struct nbd_thread_args *a = v;
    a->status = ioctl(a->fd, NBD_DO_IT);
    if (a->status < 0 && !interrupted) perror("NBD_DO_IT");
    return NULL;
}

static int dev_is_free(const char *dev) {
    const char *base = strrchr(dev, '/');
    if (!base || strncmp(dev, "/dev/nbd", 8)) return 0;
    const char *n = dev + 8;
    if (!*n) return 0;
    for (const char *p = n; *p; p++) if (*p < '0' || *p > '9') return 0;
    char path[128];
    snprintf(path, sizeof path, "/sys/block/nbd%s/pid", n);
    FILE *f = fopen(path, "r");
    if (f) {
        char data[128];
        if (fgets(data, sizeof data, f)) { fclose(f); fprintf(stderr, "%s already connected (pid %s)", dev, data); return 0; }
        fclose(f);
    }
    f = fopen("/proc/swaps", "r");
    if (f) {
        char line[512];
        while (fgets(line, sizeof line, f)) {
            if (strncmp(line, dev, strlen(dev)) == 0 && (line[strlen(dev)] == ' ' || line[strlen(dev)] == '\t')) {
                fclose(f); fprintf(stderr, "%s is active swap, refusing.\n", dev); return 0;
            }
        }
        fclose(f);
    }
    return 1;
}

static int serve(int fd, struct gpu *g) {
    uint8_t *buf = malloc(MAX_IO);
    if (!buf) return -1;
    int result = 0;
    while (!interrupted) {
        struct nbd_request request;
        if (recv_all(fd, &request, sizeof request)) break;
        if (ntohl(request.magic) != MAGIC_REQ) { fprintf(stderr, "Invalid NBD request magic.\n"); result = -1; break; }
        uint32_t opcode = ntohl(request.type) & 0xffffu;
        uint32_t length = ntohl(request.len);
        uint64_t offset = be64(request.from);
        if (opcode == NBD_CMD_DISC) break;
        struct nbd_reply reply = {0};
        reply.magic = htonl(MAGIC_REP);
        memcpy(reply.handle, request.handle, sizeof reply.handle);
        int err = 0;
        bool in_bounds = offset <= g->bytes && length <= g->bytes - offset;
        if (length > MAX_IO && (opcode == NBD_CMD_WRITE || opcode == NBD_CMD_READ)) {
            fprintf(stderr, "Rejecting NBD %s transfer of %u bytes (maximum %u); keeping connection alive.\n",
                    opcode == NBD_CMD_WRITE ? "WRITE" : "READ", length, MAX_IO);
            if (opcode == NBD_CMD_WRITE && drain_write_payload(fd, buf, length)) {
                result = -1;
                break;
            }
            err = E2BIG;
        } else if (opcode == NBD_CMD_WRITE) {
            if (recv_all(fd, buf, length)) { result = -1; break; }
            if (!in_bounds) err = EINVAL;
            else if (clEnqueueWriteBuffer(g->queue, g->buffer, CL_TRUE, (size_t)offset, length, buf, 0, NULL, NULL) != CL_SUCCESS) err = EIO;
        } else if (opcode == NBD_CMD_READ) {
            if (!in_bounds) err = EINVAL;
            else if (clEnqueueReadBuffer(g->queue, g->buffer, CL_TRUE, (size_t)offset, length, buf, 0, NULL, NULL) != CL_SUCCESS) err = EIO;
        } else if (opcode == NBD_CMD_FLUSH) {
            if (clFinish(g->queue) != CL_SUCCESS) err = EIO;
        } else {
            err = EOPNOTSUPP;
        }
        reply.error = htonl((uint32_t)err);
        if (err && err != EOPNOTSUPP) fprintf(stderr, "I/O error opcode=%u off=%" PRIu64 " len=%u error=%d\n", opcode, offset, length, err);
        if (send_all(fd, &reply, sizeof reply)) { result = -1; break; }
        if (opcode == NBD_CMD_READ && !err && send_all(fd, buf, length)) { result = -1; break; }
    }
    free(buf);
    return result;
}

int main(int argc, char **argv) {
    if (argc != 5 || strcmp(argv[1], "--device") || strcmp(argv[3], "--mib")) {
        fprintf(stderr, "Usage: sudo %s --device /dev/nbd15 --mib 128\n", argv[0]);
        fprintf(stderr, "TEST ONLY. Do not use swapon, mkswap, mkfs or important files.\n");
        return 2;
    }
    char *end = NULL;
    unsigned long mb = strtoul(argv[4], &end, 10);
    if (!*argv[4] || !end || *end || mb < 64 || mb > 8192 || !dev_is_free(argv[2])) {
        fprintf(stderr, "Use a free /dev/nbdN and --mib 64..8192.\n"); return 2;
    }
    if (geteuid() != 0) { fprintf(stderr, "Need root for NBD device ioctls.\n"); return 2; }
    signal(SIGPIPE, SIG_IGN);
    struct sigaction sa = {0}; sa.sa_handler = stop_signal;
    sigemptyset(&sa.sa_mask); sigaction(SIGINT, &sa, NULL); sigaction(SIGTERM, &sa, NULL);
    struct gpu gpu = {0};
    uint64_t bytes = (uint64_t)mb * 1024u * 1024u;
    if (gpu_init(&gpu, bytes)) return 1;
    int nbd = open(argv[2], O_RDWR | O_CLOEXEC);
    if (nbd < 0) { perror("open NBD device"); gpu_destroy(&gpu); return 1; }
    int sv[2];
    if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, sv)) { perror("socketpair"); close(nbd); gpu_destroy(&gpu); return 1; }
    if (ioctl(nbd, NBD_SET_BLKSIZE, BLKSIZE) < 0 ||
        ioctl(nbd, NBD_SET_SIZE_BLOCKS, (unsigned long)(bytes / BLKSIZE)) < 0 ||
        ioctl(nbd, NBD_SET_TIMEOUT, 60ul) < 0 ||
        ioctl(nbd, NBD_SET_FLAGS, NBD_FLAG_HAS_FLAGS | NBD_FLAG_SEND_FLUSH) < 0 ||
        ioctl(nbd, NBD_SET_SOCK, sv[1]) < 0) {
        perror("NBD ioctl setup"); close(sv[0]); close(sv[1]); close(nbd); gpu_destroy(&gpu); return 1;
    }
    struct nbd_thread_args args = {.fd = nbd, .status = -1};
    pthread_t worker;
    if (pthread_create(&worker, NULL, nbd_thread, &args) != 0) {
        fprintf(stderr, "Cannot start NBD thread\n");
        ioctl(nbd, NBD_CLEAR_SOCK); close(sv[0]); close(sv[1]); close(nbd); gpu_destroy(&gpu); return 1;
    }
    fprintf(stderr, "READY %s: %lu MiB backed by AMD OpenCL. CTRL+C to disconnect. NO SWAP.\n", argv[2], mb);
    int r = serve(sv[0], &gpu);
    /* Interrupt the kernel-side NBD handler and release the device. */
    interrupted = 1;
    ioctl(nbd, NBD_DISCONNECT);
    shutdown(sv[0], SHUT_RDWR);
    shutdown(sv[1], SHUT_RDWR);
    close(sv[0]); close(sv[1]);
    pthread_join(worker, NULL);
    ioctl(nbd, NBD_CLEAR_QUE);
    ioctl(nbd, NBD_CLEAR_SOCK);
    close(nbd);
    gpu_destroy(&gpu);
    fprintf(stderr, "NBD detached and VRAM released.\n");
    return r ? 1 : 0;
}
