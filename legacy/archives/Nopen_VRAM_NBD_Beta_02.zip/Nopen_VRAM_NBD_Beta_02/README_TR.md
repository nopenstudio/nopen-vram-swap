# Nopen VRAM-NBD Beta 0.2 — AMD / RDNA 4 deney sürümü

**SWAP olarak kullanmayın.** Program yalnızca geçici, boş bir `/dev/nbdN` aygıtında ham veri yazma ve geri okuma doğrulaması içindir. GPU reseti, sistem kilitlenmesi veya veri kaybı mümkündür. Normal SSD ve ZRAM ayarları değiştirilmez.

## 0.1 → 0.2 değişikliği

İlk sürümde `MAX_IO` sadece 1 MiB idi. Linux bazı 1 MiB yazmaları **4 MiB tek bir NBD isteğinde** birleştirdiğinden program `Oversized NBD transfer (4194304)` mesajıyla bağlantıyı koparıyordu. Bu sürümde sınır **16 MiB**. Bundan büyük okuma/yazma istekleri, bağlantıyı hemen koparmak yerine uygun hata cevabı alıyor; WRITE durumunda gelen veriler önce tüketilerek protokol hizası korunuyor.

Bu hata düzeltmesi başarılı okuma/yazmayı **garanti etmez**. Donanım üzerinde ilk test yapılacaktır.

## Derleme (Garuda Linux)

```bash
cd ~/nopen-vram-experiment/nbd-beta-02/Nopen_VRAM_NBD_Beta_02
make clean && make
```

Paketler eksikse `sudo pacman -S --needed base-devel opencl-headers ocl-icd` kullanılabilir. `clinfo -l` kartı `gfx1200` olarak gösteriyor olmalı.

## Ön koşullar

Açık önemli dosyaları kaydedin. Eski NBD programı kapalı ve aygıt boş olsun. Önce şunları kontrol edin:

```bash
swapon --show
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
cat /sys/block/nbd15/pid 2>/dev/null || echo 'nbd15: aktif süreç yok'
```

Birinci terminal (yalnızca boş, bu deneye ayrılmış /dev/nbd15 için):

```bash
sudo modprobe nbd nbds_max=16 max_part=0
cd ~/nopen-vram-experiment/nbd-beta-02/Nopen_VRAM_NBD_Beta_02
sudo ./nopen-vram-nbd --device /dev/nbd15 --mib 128
```

`READY ... 128 MiB` mesajını görünce programı açık tutun. Sadece 128 MiB'lık bu deneysel aygıtın bağlı olduğundan emin olun.

İkinci terminal (paketin `test-nbd.sh` betiği önkoşulları, 16 MiB yazmayı ve bit-bit okumayı kontrol eder):

```bash
cd ~/nopen-vram-experiment/nbd-beta-02/Nopen_VRAM_NBD_Beta_02
./test-nbd.sh
```

Bu betik Bash ile çalışır, `set -euo pipefail` kullanır ve komut başarısız olursa başarı mesajı yazmaz.

Testten sonra ilk terminalde CTRL+C ve ikinci terminalde:

```bash
rm -f /tmp/nopen-nbd-source.bin
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS
swapon --show
```

**YAPMAYIN:** `mkswap`, `swapon`, `mkfs`, `mount` veya `/dev/nbd15` üstünde bölümleme. Beta 0.2 sürümünde mlock, deadlock önleme, sürücü hata kurtarma ve bellek baskısı testi yok. Yalnızca read/write laboratuvar deneyi.
